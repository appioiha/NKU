#include <clock.h>
#include <console.h>
#include <defs.h>
#include <intr.h>
#include <kdebug.h>
#include <kmonitor.h>
#include <pmm.h>
#include <stdio.h>
#include <string.h>
#include <trap.h>
#include <dtb.h>

int kern_init(void) __attribute__((noreturn));
void grade_backtrace(void);

int kern_init(void) {
    extern char edata[], end[];
    // 先清零 BSS，再读取并保存 DTB 的内存信息，避免被清零覆盖（为了解释变化 正式上传时我觉得应该删去这句话）
    memset(edata, 0, end - edata);
    dtb_init();
    cons_init();  // init the console
    const char *message = "(THU.CST) os is loading ...\0";
    //cprintf("%s\n\n", message);
    cputs(message);

    print_kerninfo();

    // grade_backtrace();
    idt_init();  // init interrupt descriptor table

    pmm_init();  // init physical memory management

    idt_init();  // init interrupt descriptor table

    clock_init();   // init clock interrupt
    intr_enable();  // enable irq interrupt

    // 延迟测试异常，确保系统稳定运行
    for (volatile int i = 0; i < 1000000; i++); // 简单延时
    
    cprintf("Testing exceptions...\n");
    
    // 测试1：非法指令异常
    cprintf("1. Testing illegal instruction exception:\n");
    asm volatile(
        ".word 0x00000000 \n"  // 非法指令
        "j 1f \n"              // 跳转到标签1，如果异常处理正确会跳过这条指令
        "1: \n"
    );
    
    // 测试2：断点异常  
    cprintf("2. Testing breakpoint exception:\n");
    asm volatile(
        "ebreak \n"           // 断点指令
        "j 2f \n"             // 跳转到标签2，如果异常处理正确会跳过这条指令
        "2: \n"
    );
    
    cprintf("Exception tests completed successfully!\n");

    /* do nothing */
    while (1)
        ;
}

void __attribute__((noinline))
grade_backtrace2(int arg0, int arg1, int arg2, int arg3) {
    mon_backtrace(0, NULL, NULL);
}

void __attribute__((noinline)) grade_backtrace1(int arg0, int arg1) {
    grade_backtrace2(arg0, (uintptr_t)&arg0, arg1, (uintptr_t)&arg1);
}

void __attribute__((noinline)) grade_backtrace0(int arg0, int arg1, int arg2) {
    grade_backtrace1(arg0, arg2);
}

void grade_backtrace(void) { grade_backtrace0(0, (uintptr_t)kern_init, 0xffff0000); }

