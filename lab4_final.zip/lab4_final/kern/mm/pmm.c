#include <default_pmm.h>
#include <defs.h>
#include <error.h>
#include <kmalloc.h>
#include <memlayout.h>
#include <mmu.h>
#include <pmm.h>
#include <sbi.h>
#include <stdio.h>
#include <string.h>
#include <sync.h>
#include <vmm.h>
#include <riscv.h>
#include <dtb.h>

// 物理页描述符数组的虚拟地址：每个元素对应一个物理页的管理信息
struct Page *pages;
// 物理内存总页数（整个系统可用物理页的数量）
size_t npage = 0;
// 虚拟地址与物理地址的偏移量（内核虚拟地址 = 物理地址 + 此偏移量）
uint_t va_pa_offset;
// RISC-V架构下内存起始地址（0x80000000）对应的页号（作为物理页索引的基准）
const size_t nbase = DRAM_BASE / PGSIZE;

// 启动时页目录的虚拟地址（内核态访问页目录的入口）
pde_t *boot_pgdir_va = NULL;
// 启动时页目录的物理地址（用于设置satp寄存器，让CPU识别页目录）
uintptr_t boot_pgdir_pa;

// 物理内存管理器实例（指向默认的首次适配分配器）
const struct pmm_manager *pmm_manager;

// 声明内部检查函数（验证内存分配、页目录正确性）
static void check_alloc_page(void);
static void check_pgdir(void);
static void check_boot_pgdir(void);

/**
 * @brief 初始化物理内存管理器
 * 功能：指定使用的物理内存分配算法（默认首次适配），并初始化分配器
 */
static void init_pmm_manager(void)
{
    pmm_manager = &default_pmm_manager;  // 绑定默认的物理内存管理器
    cprintf("memory management: %s\n", pmm_manager->name);  // 打印分配器名称（调试用）
    pmm_manager->init();  // 调用分配器的初始化函数（如初始化空闲链表）
}

/**
 * @brief 初始化物理内存映射表
 * @param base 空闲内存块的起始页描述符
 * @param n 该内存块包含的连续页数
 * 功能：调用物理内存管理器的接口，为空闲内存块建立页描述符链表
 */
static void init_memmap(struct Page *base, size_t n)
{
    pmm_manager->init_memmap(base, n);  // 委托分配器初始化空闲块
}

/**
 * @brief 分配n个连续的物理页
 * @param n 需求的连续页数
 * @return 成功：返回起始页的描述符指针；失败：NULL
 * 功能：封装分配器接口，通过关中断保证分配操作的原子性
 */
struct Page *alloc_pages(size_t n)
{
    struct Page *page = NULL;
    bool intr_flag;  // 保存中断状态的变量
    local_intr_save(intr_flag);  // 禁用中断（临界区保护）
    {
        page = pmm_manager->alloc_pages(n);  // 调用分配器分配连续页
    }
    local_intr_restore(intr_flag);  // 恢复中断状态
    return page;
}

/**
 * @brief 释放n个连续的物理页
 * @param base 待释放内存块的起始页描述符
 * @param n 待释放的连续页数
 * 功能：封装分配器接口，通过关中断保证释放操作的原子性
 */
void free_pages(struct Page *base, size_t n)
{
    bool intr_flag;
    local_intr_save(intr_flag);  // 禁用中断（临界区保护）
    {
        pmm_manager->free_pages(base, n);  // 调用分配器释放连续页
    }
    local_intr_restore(intr_flag);  // 恢复中断状态
}

/**
 * @brief 获取当前空闲物理页的总数
 * @return 空闲页数量
 * 功能：封装分配器接口，关中断保证计数的准确性
 */
size_t nr_free_pages(void)
{
    size_t ret;
    bool intr_flag;
    local_intr_save(intr_flag);  // 禁用中断（避免计数过程中被打断）
    {
        ret = pmm_manager->nr_free_pages();  // 调用分配器获取空闲页计数
    }
    local_intr_restore(intr_flag);  // 恢复中断状态
    return ret;
}

/**
 * @brief 物理内存初始化核心函数
 * 功能：1. 从DTB获取物理内存信息；2. 初始化页描述符数组；3. 标记已使用内存；4. 初始化空闲内存块
 */
static void page_init(void)
{
    extern char kern_entry[];  // 内核入口地址（链接脚本定义，标记内核代码起始位置）

    va_pa_offset = PHYSICAL_MEMORY_OFFSET;  // 初始化虚实地址偏移量（内核态固定偏移）

    // 从DTB中提取物理内存信息（基地址和大小，DTB由bootloader传入）
    uint64_t mem_begin = get_memory_base();  // 物理内存起始地址
    uint64_t mem_size  = get_memory_size();  // 物理内存总大小
    if (mem_size == 0) {
        panic("DTB memory info not available");  // 未获取到内存信息，内核 panic
    }
    uint64_t mem_end   = mem_begin + mem_size;  // 物理内存结束地址

    // 打印物理内存映射信息（调试用）
    cprintf("physcial memory map:\n");
    cprintf("  memory: 0x%08lx, [0x%08lx, 0x%08lx].\n", mem_size, mem_begin,
            mem_end - 1);

    uint64_t maxpa = mem_end;  // 物理内存最大地址
    if (maxpa > KERNTOP)  // 限制物理内存最大地址不超过内核虚拟地址上限
    {
        maxpa = KERNTOP;
    }

    extern char end[];  // 内核代码结束地址（链接脚本定义，标记内核占用内存的末尾）

    npage = maxpa / PGSIZE;  // 计算物理内存总页数（总地址 / 页大小）
    // 页描述符数组pages的虚拟地址：内核结束地址按页对齐（避免与内核代码重叠）
    pages = (struct Page *)ROUNDUP((void *)end, PGSIZE);

    // 初始化页描述符数组：标记所有物理页为"保留"（已使用）
    for (size_t i = 0; i < npage - nbase; i++)
    {
        SetPageReserved(pages + i);  // 置位PG_reserved标志，标识页不可分配
    }

    // 计算空闲内存的起始地址：页描述符数组之后的内存（按页对齐）
    uintptr_t freemem = PADDR((uintptr_t)pages + sizeof(struct Page) * (npage - nbase));
    mem_begin = ROUNDUP(freemem, PGSIZE);  // 空闲内存起始地址按页对齐
    mem_end = ROUNDDOWN(mem_end, PGSIZE);  // 空闲内存结束地址按页对齐

    // 初始化空闲内存块（若存在空闲内存）
    if (freemem < mem_end)
    {
        // 将物理地址转换为页描述符指针，初始化空闲块（页数 = 内存大小 / 页大小）
        init_memmap(pa2page(mem_begin), (mem_end - mem_begin) / PGSIZE);
    }
    cprintf("vapaofset is %llu\n", va_pa_offset);  // 打印虚实地址偏移量（调试用）
}

/**
 * @brief 启用分页机制
 * 功能：设置RISC-V的satp寄存器，让CPU使用页目录进行地址转换
 * 注：satp寄存器格式：MODE(8位) | ASID(16位) | PPN(40位)，此处MODE=Sv39（8000000000000000）
 */
static void enable_paging(void)
{
    // 写入satp：Sv39模式 + 页目录物理页号（boot_pgdir_pa右移页偏移位）
    write_csr(satp, 0x8000000000000000 | (boot_pgdir_pa >> RISCV_PGSHIFT));
}

/**
 * @brief 启动时映射内存段（建立虚拟地址到物理地址的映射）
 * @param pgdir 页目录虚拟地址
 * @param la 虚拟地址（待映射的线性地址）
 * @param size 内存段大小
 * @param pa 物理地址（虚拟地址对应的物理地址）
 * @param perm 内存段权限（如读、写、用户态访问等）
 * 功能：为内核启动过程中需要的内存段（如内核代码、数据段）建立页表映射
 */
static void boot_map_segment(pde_t *pgdir, uintptr_t la, size_t size,
                             uintptr_t pa, uint32_t perm)
{
    assert(PGOFF(la) == PGOFF(pa));  // 确保虚拟地址和物理地址的页内偏移一致
    // 计算需要映射的页数（向上取整，确保覆盖整个内存段）
    size_t n = ROUNDUP(size + PGOFF(la), PGSIZE) / PGSIZE;
    la = ROUNDDOWN(la, PGSIZE);  // 虚拟地址按页对齐
    pa = ROUNDDOWN(pa, PGSIZE);  // 物理地址按页对齐

    // 为每个页建立映射
    for (; n > 0; n--, la += PGSIZE, pa += PGSIZE)
    {
        pte_t *ptep = get_pte(pgdir, la, 1);  // 获取或创建页表项
        assert(ptep != NULL);  // 确保页表项创建成功
        // 构建页表项：物理页号 + 有效位（PTE_V） + 权限
        *ptep = pte_create(pa >> PGSHIFT, PTE_V | perm);
    }
}

/**
 * @brief 启动时分配物理页（用于创建页目录/页表）
 * @return 分配页的内核虚拟地址
 * 功能：为页目录、页表等内核关键数据结构分配物理页，保证启动过程正常
 */
static void *boot_alloc_page(void)
{
    struct Page *p = alloc_page();  // 分配1个物理页
    if (p == NULL)
    {
        panic("boot_alloc_page failed.\n");  // 分配失败则内核 panic
    }
    return page2kva(p);  // 转换为内核虚拟地址并返回
}

/**
 * @brief 物理内存管理初始化入口
 * 功能：1. 初始化物理内存管理器；2. 探测物理内存；3. 建立启动页表；4. 验证内存管理正确性
 */
void pmm_init(void)
{
    // 1. 初始化物理内存管理器（指定分配算法）
    init_pmm_manager();

    // 2. 探测物理内存，标记已使用内存，初始化空闲内存块
    page_init();

    // 3. 验证物理内存分配器的正确性
    check_alloc_page();

    // 4. 初始化启动页目录（使用链接脚本中定义的页表模板）
    extern char boot_page_table_sv39[];
    boot_pgdir_va = (pte_t *)boot_page_table_sv39;  // 页目录虚拟地址
    boot_pgdir_pa = PADDR(boot_pgdir_va);  // 页目录物理地址（虚实地址转换）

    // 5. 验证页目录操作的正确性
    check_pgdir();

    // 断言：内核虚拟地址范围按页表大小对齐（Sv39模式下PTSIZE=1GB）
    static_assert(KERNBASE % PTSIZE == 0 && KERNTOP % PTSIZE == 0);

    // 6. 验证启动页表映射的正确性
    check_boot_pgdir();

    // 7. 初始化内核内存分配器（kmalloc），基于物理内存管理实现
    kmalloc_init();
}

/**
 * @brief 获取虚拟地址对应的页表项（Sv39模式，3级页表）
 * @param pgdir 页目录虚拟地址
 * @param la 目标虚拟地址
 * @param create 若页表不存在，是否创建（1=创建，0=不创建）
 * @return 成功：页表项的虚拟地址；失败：NULL
 * 功能：遍历3级页表，找到虚拟地址对应的页表项，不存在则创建中间页表
 */
pte_t *get_pte(pde_t *pgdir, uintptr_t la, bool create)
{
    // 第1级页表项（Sv39模式：虚拟地址高9位为第1级索引）
    pde_t *pdep1 = &pgdir[PDX1(la)];
    if (!(*pdep1 & PTE_V))  // 第1级页表项未有效（无对应的第2级页表）
    {
        struct Page *page;
        if (!create || (page = alloc_page()) == NULL)  // 不创建或分配失败
        {
            return NULL;
        }
        set_page_ref(page, 1);  // 页引用计数置1（标记被第1级页表引用）
        uintptr_t pa = page2pa(page);  // 第2级页表的物理地址
        memset(KADDR(pa), 0, PGSIZE);  // 初始化第2级页表（清零）
        // 构建第1级页表项：第2级页表的物理页号 + 有效位（PTE_V） + 用户态权限（PTE_U）
        *pdep1 = pte_create(page2ppn(page), PTE_U | PTE_V);
    }

    // 第2级页表项（Sv39模式：虚拟地址中9位为第2级索引）
    pde_t *pdep0 = &((pte_t *)KADDR(PDE_ADDR(*pdep1)))[PDX0(la)];
    if (!(*pdep0 & PTE_V))  // 第2级页表项未有效（无对应的第3级页表）
    {
        struct Page *page;
        if (!create || (page = alloc_page()) == NULL)  // 不创建或分配失败
        {
            return NULL;
        }
        set_page_ref(page, 1);  // 页引用计数置1（标记被第2级页表引用）
        uintptr_t pa = page2pa(page);  // 第3级页表的物理地址
        memset(KADDR(pa), 0, PGSIZE);  // 初始化第3级页表（清零）
        // 构建第2级页表项：第3级页表的物理页号 + 有效位（PTE_V） + 用户态权限（PTE_U）
        *pdep0 = pte_create(page2ppn(page), PTE_U | PTE_V);
    }

    // 第3级页表项（Sv39模式：虚拟地址低9位为第3级索引）
    return &((pte_t *)KADDR(PDE_ADDR(*pdep0)))[PTX(la)];
}

/**
 * @brief 获取虚拟地址对应的物理页描述符
 * @param pgdir 页目录虚拟地址
 * @param la 目标虚拟地址
 * @param ptep_store 用于存储页表项地址（可为NULL）
 * @return 成功：物理页描述符指针；失败：NULL
 * 功能：通过虚拟地址查找对应的物理页，支持返回页表项地址用于后续操作
 */
struct Page *get_page(pde_t *pgdir, uintptr_t la, pte_t **ptep_store)
{
    pte_t *ptep = get_pte(pgdir, la, 0);  // 查找页表项（不创建新页表）
    if (ptep_store != NULL)
    {
        *ptep_store = ptep;  // 保存页表项地址（若需要）
    }
    // 页表项有效则返回对应的物理页描述符
    if (ptep != NULL && *ptep & PTE_V)
    {
        return pte2page(*ptep);
    }
    return NULL;  // 页表项无效或未找到
}

/**
 * @brief 移除虚拟地址对应的页表项，并释放物理页（内部辅助函数）
 * @param pgdir 页目录虚拟地址
 * @param la 目标虚拟地址
 * @param ptep 页表项地址
 * 功能：1. 减少物理页引用计数；2. 引用为0则释放物理页；3. 清除页表项并刷新TLB
 */
static inline void page_remove_pte(pde_t *pgdir, uintptr_t la, pte_t *ptep)
{
    if (*ptep & PTE_V)  // 页表项有效（存在对应的物理页）
    {
        struct Page *page = pte2page(*ptep);  // 转换为物理页描述符
        page_ref_dec(page);  // 减少页引用计数（解除虚拟地址的引用）
        if (page_ref(page) == 0)  // 引用计数为0，说明无虚拟地址引用此页
        {
            free_page(page);  // 释放物理页
        }
        *ptep = 0;  // 清除页表项（标记为无效）
        tlb_invalidate(pgdir, la);  // 刷新TLB（避免CPU缓存旧的页表项）
    }
}

/**
 * @brief 移除虚拟地址对应的映射关系
 * @param pgdir 页目录虚拟地址
 * @param la 目标虚拟地址
 * 功能：删除虚拟地址到物理地址的映射，释放对应的物理页（引用为0时）
 */
void page_remove(pde_t *pgdir, uintptr_t la)
{
    pte_t *ptep = get_pte(pgdir, la, 0);  // 查找页表项（不创建新页表）
    if (ptep != NULL)
    {
        page_remove_pte(pgdir, la, ptep);  // 移除页表项并释放物理页
    }
}

/**
 * @brief 建立物理页到虚拟地址的映射
 * @param pgdir 页目录虚拟地址
 * @param page 待映射的物理页描述符
 * @param la 目标虚拟地址
 * @param perm 映射的权限（如读、写、执行、用户态访问等）
 * @return 成功：0；失败：-E_NO_MEM（内存不足）
 * 功能：将指定物理页映射到虚拟地址，支持权限控制，已存在映射则替换
 */
int page_insert(pde_t *pgdir, struct Page *page, uintptr_t la, uint32_t perm)
{
    pte_t *ptep = get_pte(pgdir, la, 1);  // 获取或创建页表项
    if (ptep == NULL)
    {
        return -E_NO_MEM;  // 页表创建失败（内存不足）
    }
    page_ref_inc(page);  // 增加物理页引用计数（新虚拟地址引用此页）

    if (*ptep & PTE_V)  // 该虚拟地址已存在映射
    {
        struct Page *p = pte2page(*ptep);  // 获取原映射的物理页
        if (p == page)  // 映射到同一个物理页，无需修改
        {
            page_ref_dec(page);  // 减少引用计数（刚才的增量无效）
        }
        else  // 映射到新的物理页，移除原映射
        {
            page_remove_pte(pgdir, la, ptep);
        }
    }

    // 构建新的页表项：物理页号 + 有效位（PTE_V） + 权限
    *ptep = pte_create(page2ppn(page), PTE_V | perm);
    tlb_invalidate(pgdir, la);  // 刷新TLB（应用新的页表项）
    return 0;
}

/**
 * @brief 刷新TLB（Translation Lookaside Buffer）
 * @param pgdir 页目录虚拟地址（未使用，兼容接口）
 * @param la 目标虚拟地址
 * 功能：使CPU缓存的页表项失效，确保后续地址转换使用最新的页表
 */
void tlb_invalidate(pde_t *pgdir, uintptr_t la)
{
    // RISC-V架构下使用sfence.vma指令刷新TLB，la为虚拟地址（0表示刷新所有）
    asm volatile("sfence.vma %0" : : "r"(la));
}

/**
 * @brief 验证物理内存分配器的正确性
 * 功能：调用分配器的check接口，测试分配、释放等核心操作
 */
static void check_alloc_page(void)
{
    pmm_manager->check();  // 分配器自校验（如分配3页、释放后计数正确等）
    cprintf("check_alloc_page() succeeded!\n");  // 打印校验成功信息
}

/**
 * @brief 验证页目录和页表操作的正确性
 * 功能：测试页表项创建、映射替换、物理页引用计数等核心逻辑
 */
static void check_pgdir(void)
{
    size_t nr_free_store = nr_free_pages();  // 保存初始空闲页数量

    // 断言：物理内存总页数不超过内核虚拟地址上限
    assert(npage <= KERNTOP / PGSIZE);
    // 断言：页目录地址有效且按页对齐
    assert(boot_pgdir_va != NULL && (uint32_t)PGOFF(boot_pgdir_va) == 0);
    // 断言：虚拟地址0x0未映射（初始状态）
    assert(get_page(boot_pgdir_va, 0x0, NULL) == NULL);

    struct Page *p1, *p2;
    p1 = alloc_page();  // 分配物理页p1
    assert(page_insert(boot_pgdir_va, p1, 0x0, 0) == 0);  // 映射0x0到p1

    pte_t *ptep;
    // 验证页表项存在且对应p1
    assert((ptep = get_pte(boot_pgdir_va, 0x0, 0)) != NULL);
    assert(pte2page(*ptep) == p1);
    assert(page_ref(p1) == 1);  // 引用计数为1

    // 验证虚拟地址PGSIZE（4KB）对应的页表项地址正确
    ptep = (pte_t *)KADDR(PDE_ADDR(boot_pgdir_va[0]));
    ptep = (pte_t *)KADDR(PDE_ADDR(ptep[0])) + 1;
    assert(get_pte(boot_pgdir_va, PGSIZE, 0) == ptep);

    p2 = alloc_page();  // 分配物理页p2
    // 映射PGSIZE到p2，权限为用户态可写（PTE_U | PTE_W）
    assert(page_insert(boot_pgdir_va, p2, PGSIZE, PTE_U | PTE_W) == 0);
    assert((ptep = get_pte(boot_pgdir_va, PGSIZE, 0)) != NULL);
    assert(*ptep & PTE_U);  // 验证权限位PTE_U
    assert(*ptep & PTE_W);  // 验证权限位PTE_W
    assert(boot_pgdir_va[0] & PTE_U);  // 第1级页表项权限正确
    assert(page_ref(p2) == 1);  // p2引用计数为1

    // 将PGSIZE的映射替换为p1
    assert(page_insert(boot_pgdir_va, p1, PGSIZE, 0) == 0);
    assert(page_ref(p1) == 2);  // p1引用计数变为2
    assert(page_ref(p2) == 0);  // p2引用计数变为0（原映射被移除）
    assert((ptep = get_pte(boot_pgdir_va, PGSIZE, 0)) != NULL);
    assert(pte2page(*ptep) == p1);  // 映射正确
    assert((*ptep & PTE_U) == 0);  // 权限位PTE_U被清除

    // 移除0x0的映射
    page_remove(boot_pgdir_va, 0x0);
    assert(page_ref(p1) == 1);  // p1引用计数变为1
    assert(page_ref(p2) == 0);  // p2引用计数仍为0

    // 移除PGSIZE的映射
    page_remove(boot_pgdir_va, PGSIZE);
    assert(page_ref(p1) == 0);  // p1引用计数变为0
    assert(page_ref(p2) == 0);  // p2引用计数仍为0

    // 验证第1级页表项对应的物理页引用计数为1
    assert(page_ref(pde2page(boot_pgdir_va[0])) == 1);

    // 释放页表占用的物理页，恢复初始状态
    pde_t *pd1 = boot_pgdir_va, *pd0 = page2kva(pde2page(boot_pgdir_va[0]));
    free_page(pde2page(pd0[0]));
    free_page(pde2page(pd1[0]));
    boot_pgdir_va[0] = 0;
    flush_tlb();  // 刷新TLB

    // 断言：空闲页数量恢复到初始值
    assert(nr_free_store == nr_free_pages());

    cprintf("check_pgdir() succeeded!\n");  // 打印校验成功信息
}

/**
 * @brief 验证启动页表映射的正确性
 * 功能：测试内核虚拟地址空间的映射、物理页共享映射等场景
 */
static void check_boot_pgdir(void)
{
    size_t nr_free_store = nr_free_pages();
    pte_t *ptep;
    int i;

    // 验证内核虚拟地址范围的映射正确性（KERNBASE到npage*PGSIZE）
    for (i = ROUNDDOWN(KERNBASE, PGSIZE); i < npage * PGSIZE; i += PGSIZE)
    {
        assert((ptep = get_pte(boot_pgdir_va, (uintptr_t)KADDR(i), 0)) != NULL);
        assert(PTE_ADDR(*ptep) == i);  // 虚拟地址对应的物理地址正确
    }

    assert(boot_pgdir_va[0] == 0);  // 验证页目录第0项为0（未映射）

    struct Page *p;
    p = alloc_page();  // 分配物理页p
    // 映射0x100到p，权限为可读写（PTE_W | PTE_R）
    assert(page_insert(boot_pgdir_va, p, 0x100, PTE_W | PTE_R) == 0);
    assert(page_ref(p) == 1);  // 引用计数为1
    // 映射0x100+PGSIZE到p（共享映射）
    assert(page_insert(boot_pgdir_va, p, 0x100 + PGSIZE, PTE_W | PTE_R) == 0);
    assert(page_ref(p) == 2);  // 引用计数变为2

    // 测试共享映射：两个虚拟地址修改同一物理页
    const char *str = "ucore: Hello world!!";
    strcpy((void *)0x100, str);  // 向0x100写入字符串
    // 验证0x100+PGSIZE读取到相同内容（共享物理页）
    assert(strcmp((void *)0x100, (void *)(0x100 + PGSIZE)) == 0);

    // 直接修改物理页内容，验证两个虚拟地址均受影响
    *(char *)(page2kva(p) + 0x100) = '\0';
    assert(strlen((const char *)0x100) == 0);  // 字符串被截断

    // 释放资源，恢复初始状态
    pde_t *pd1 = boot_pgdir_va, *pd0 = page2kva(pde2page(boot_pgdir_va[0]));
    free_page(p);
    free_page(pde2page(pd0[0]));
    free_page(pde2page(pd1[0]));
    boot_pgdir_va[0] = 0;
    flush_tlb();

    // 断言：空闲页数量恢复到初始值
    assert(nr_free_store == nr_free_pages());

    cprintf("check_boot_pgdir() succeeded!\n");  // 打印校验成功信息
}

/**
 * @brief 将页表项权限转换为字符串（用于调试打印）
 * @param perm 页表项权限
 * @return 权限字符串（格式："u,r,w,-"，u=用户态，r=读，w=写）
 */
static const char *perm2str(int perm)
{
    static char str[4];
    str[0] = (perm & PTE_U) ? 'u' : '-';  // 用户态访问权限
    str[1] = 'r';  // 读权限（默认开启）
    str[2] = (perm & PTE_W) ? 'w' : '-';  // 写权限
    str[3] = '\0';
    return str;
}

/**
 * @brief 提取页表中连续的有效项（用于调试打印页表）
 * @param left 无效参数（预留）
 * @param right 页表项范围上限
 * @param start 页表项范围起始索引
 * @param table 页表起始地址（虚拟地址）
 * @param left_store 连续有效项的起始索引（输出）
 * @param right_store 连续有效项的结束索引（输出）
 * @return 0=无有效项，非0=有效项的权限
 * 功能：遍历页表，找到连续且权限相同的有效项，用于简化页表打印输出
 */
static int get_pgtable_items(size_t left, size_t right, size_t start,
                             uintptr_t *table, size_t *left_store,
                             size_t *right_store)
{
    if (start >= right)
    {
        return 0;  // 超出范围，无有效项
    }
    // 跳过无效页表项（未置位PTE_V）
    while (start < right && !(table[start] & PTE_V))
    {
        start++;
    }
    if (start < right)  // 找到有效页表项
    {
        if (left_store != NULL)
        {
            *left_store = start;  // 记录连续有效项的起始索引
        }
        int perm = (table[start++] & PTE_USER);  // 获取当前项的权限
        // 查找连续且权限相同的有效项
        while (start < right && (table[start] & PTE_USER) == perm)
        {
            start++;
        }
        if (right_store != NULL)
        {
            *right_store = start;  // 记录连续有效项的结束索引
        }
        return perm;  // 返回连续有效项的权限
    }
    return 0;  // 无有效项
}