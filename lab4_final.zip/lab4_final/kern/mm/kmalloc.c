#include <defs.h>
#include <list.h>
#include <memlayout.h>
#include <assert.h>
#include <kmalloc.h>
#include <sync.h>
#include <pmm.h>
#include <stdio.h>

/*
 * SLOB Allocator: Simple List Of Blocks（简单块链表分配器）
 *
 * 核心原理说明：
 * 1. 基础层：基于K&R风格的堆分配器，管理由__get_free_page分配的物理页组成的堆空间，采用首次适配算法
 * 2. kmalloc/kfree实现：
 *    - 小对象（小于PAGE_SIZE - 头部大小）：8字节对齐，带8字节头部，从堆空间分配
 *    - 大对象（大于等于PAGE_SIZE）：直接调用__get_free_pages分配页对齐块，单独维护链表
 * 3. SLAB模拟：通过为每个SLAB分配调用构造/析构函数实现，支持缓存对齐（SLAB_MUST_HWCACHE_ALIGN）
 * 优势：实现简单、空间开销小；劣势：分配效率和内存碎片控制弱于SLAB
 */

// 辅助宏定义：中断开关与自旋锁结合（简化临界区保护）
#define spin_lock_irqsave(l, f) local_intr_save(f)  // 禁用中断并保存状态（模拟自旋锁加锁）
#define spin_unlock_irqrestore(l, f) local_intr_restore(f)  // 恢复中断状态（模拟自旋锁解锁）
typedef unsigned int gfp_t;  // 内存分配标志类型（兼容Linux风格，本实现未实际使用）

// 页大小定义（复用物理内存页大小PGSIZE）
#ifndef PAGE_SIZE
#define PAGE_SIZE PGSIZE
#endif

// L1缓存行大小（用于内存对齐优化）
#ifndef L1_CACHE_BYTES
#define L1_CACHE_BYTES 64
#endif

// 地址对齐宏：将addr按size对齐（向上取整）
#ifndef ALIGN
#define ALIGN(addr, size) (((addr) + (size) - 1) & (~((size) - 1)))
#endif

/**
 * @brief 小内存块结构体（用于管理小于PAGE_SIZE的空闲内存）
 */
struct slob_block
{
    int units;          // 块大小（以SLOB_UNIT为单位）
    struct slob_block *next;  // 指向链表中下一个空闲块
};
typedef struct slob_block slob_t;

// 小内存块的单位大小（等于slob_t结构体大小，本实现中为8字节）
#define SLOB_UNIT sizeof(slob_t)
// 将字节大小转换为SLOB_UNIT单位（向上取整）
#define SLOB_UNITS(size) (((size) + SLOB_UNIT - 1) / SLOB_UNIT)
// 小内存块的对齐要求（与L1缓存行对齐，减少缓存失效）
#define SLOB_ALIGN L1_CACHE_BYTES

/**
 * @brief 大内存块结构体（用于管理大于等于PAGE_SIZE的空闲内存）
 */
struct bigblock
{
    int order;          // 分配的页级数（2^order个连续页）
    void *pages;        // 指向分配的物理页的虚拟地址
    struct bigblock *next;  // 指向链表中下一个大内存块
};
typedef struct bigblock bigblock_t;

// 全局变量：小内存块堆的哨兵节点（构成循环链表）
static slob_t arena = {.next = &arena, .units = 1};
// 全局变量：小内存块空闲链表头指针
static slob_t *slobfree = &arena;
// 全局变量：大内存块空闲链表头指针
static bigblock_t *bigblocks;

// 全局锁：保护小内存块链表的并发访问（临界区保护）
static struct spinlock slob_lock = SPINLOCK_INIT();
// 全局锁：保护大内存块链表的并发访问（临界区保护）
static struct spinlock block_lock = SPINLOCK_INIT();

/**
 * @brief 分配2^order个连续的物理页，并返回其虚拟地址
 * @param gfp 内存分配标志（本实现未使用）
 * @param order 页级数（分配页数 = 2^order）
 * @return 成功：页的虚拟地址；失败：NULL
 */
static void *__slob_get_free_pages(gfp_t gfp, int order)
{
    // 调用物理内存管理模块的alloc_pages分配连续页
    struct Page *page = alloc_pages(1 << order);
    if (!page)
        return NULL;
    // 将物理页转换为内核虚拟地址（KVA）并返回
    return page2kva(page);
}

// 宏定义：分配1个物理页（order=0，2^0=1页）
#define __slob_get_free_page(gfp) __slob_get_free_pages(gfp, 0)

/**
 * @brief 释放2^order个连续的物理页
 * @param kva 待释放页的虚拟地址
 * @param order 页级数（与分配时的order一致）
 */
static inline void __slob_free_pages(unsigned long kva, int order)
{
    // 将虚拟地址转换为Page结构体指针，调用free_pages释放
    free_pages(kva2page(kva), 1 << order);
}

// 前向声明：小内存块释放函数（供slob_alloc调用）
static void slob_free(void *b, int size);

/**
 * @brief 小内存块分配核心函数（分配小于PAGE_SIZE的内存）
 * @param size 需求内存大小（字节）
 * @param gfp 分配标志（未使用）
 * @param align 对齐要求（0表示默认对齐，非0表示指定对齐大小）
 * @return 成功：分配的内存块虚拟地址；失败：NULL
 */
static void *slob_alloc(size_t size, gfp_t gfp, int align)
{
    // 断言：分配大小+块头部不会超过1页（小内存块定义）
    assert((size + SLOB_UNIT) < PAGE_SIZE);

    slob_t *prev, *cur, *aligned = 0;  // prev：前驱块；cur：当前块；aligned：对齐后的块
    int delta = 0;  // 对齐所需的偏移量（当前块到对齐块的距离）
    int units = SLOB_UNITS(size);  // 需求大小转换为SLOB_UNIT单位
    unsigned long flags;  // 保存中断状态

    // 进入临界区：禁用中断+加锁，保护链表操作原子性
    spin_lock_irqsave(&slob_lock, flags);
    prev = slobfree;  // 从空闲链表头开始遍历
    for (cur = prev->next;; prev = cur, cur = cur->next)
    {
        if (align)
        {
            // 计算当前块对齐后的地址（按align要求）
            aligned = (slob_t *)ALIGN((unsigned long)cur, align);
            delta = aligned - cur;  // 计算偏移量（单位：slob_t）
        }

        // 检查当前块（或对齐后的块）是否满足大小需求
        if (cur->units >= units + delta)
        {
            if (delta)
            {
                // 需拆分当前块以满足对齐要求：在对齐位置创建新块
                aligned->units = cur->units - delta;  // 新块大小 = 原块大小 - 偏移量
                aligned->next = cur->next;            // 新块指向原块的下一个块
                cur->next = aligned;                  // 原块指向新块
                cur->units = delta;                   // 原块大小更新为偏移量
                prev = cur;                           // 前驱块指向原块（新块成为当前块）
                cur = aligned;
            }

            if (cur->units == units)
            {
                // 块大小完全匹配：直接从链表中移除当前块
                prev->next = cur->next;
            }
            else
            {
                // 块大小大于需求：拆分当前块，保留剩余部分
                prev->next = cur + units;              // 前驱块指向剩余块
                prev->next->units = cur->units - units;  // 剩余块大小 = 原块大小 - 需求大小
                prev->next->next = cur->next;          // 剩余块继承原块的后续指针
                cur->units = units;                   // 当前块大小更新为需求大小
            }

            slobfree = prev;  // 更新空闲链表头（优化下次分配效率）
            spin_unlock_irqrestore(&slob_lock, flags);  // 退出临界区
            return cur;  // 返回分配的块地址
        }

        // 遍历到链表末尾（循环链表），说明当前堆空间不足
        if (cur == slobfree)
        {
            spin_unlock_irqrestore(&slob_lock, flags);  // 临时解锁，避免死锁

            // 若需求大小等于页大小，说明是尝试收缩堆，直接返回失败
            if (size == PAGE_SIZE)
                return 0;

            // 分配新的物理页，扩展堆空间
            cur = (slob_t *)__slob_get_free_page(gfp);
            if (!cur)
                return 0;  // 物理内存不足，分配失败

            // 将新页作为空闲块加入小内存块链表
            slob_free(cur, PAGE_SIZE);
            // 重新加锁，继续遍历分配
            spin_lock_irqsave(&slob_lock, flags);
            cur = slobfree;
        }
    }
}

/**
 * @brief 小内存块释放核心函数
 * @param block 待释放的内存块地址
 * @param size 待释放的大小（字节，0表示从块头部读取大小）
 */
static void slob_free(void *block, int size)
{
    slob_t *cur, *b = (slob_t *)block;  // b：转换为slob_t类型的块指针
    unsigned long flags;

    if (!block)
        return;  // 空指针直接返回

    // 若指定了大小，更新块的units字段；否则使用原有值
    if (size)
        b->units = SLOB_UNITS(size);

    // 进入临界区：保护链表操作
    spin_lock_irqsave(&slob_lock, flags);
    // 遍历空闲链表，找到块的插入位置（按地址升序插入，便于合并）
    for (cur = slobfree; !(b > cur && b < cur->next); cur = cur->next)
        // 处理链表首尾衔接的情况（循环链表）
        if (cur >= cur->next && (b > cur || b < cur->next))
            break;

    // 尝试与后继块合并（检查地址是否连续）
    if (b + b->units == cur->next)
    {
        b->units += cur->next->units;  // 合并大小
        b->next = cur->next->next;    // 跳过后继块（已合并）
    }
    else
    {
        b->next = cur->next;  // 不合并，直接指向后继块
    }

    // 尝试与前驱块合并（检查地址是否连续）
    if (cur + cur->units == b)
    {
        cur->units += b->units;  // 合并大小
        cur->next = b->next;    // 跳过当前块（已合并）
    }
    else
    {
        cur->next = b;  // 不合并，前驱块指向当前块
    }

    slobfree = cur;  // 更新空闲链表头
    spin_unlock_irqrestore(&slob_lock, flags);  // 退出临界区
}

/**
 * @brief SLOB分配器初始化函数
 */
void slob_init(void)
{
    cprintf("use SLOB allocator\n");  // 打印使用的分配器类型（调试用）
}

/**
 * @brief kmalloc分配器初始化函数（对外接口）
 */
inline void
kmalloc_init(void)
{
    slob_init();  // 初始化SLOB分配器
    cprintf("kmalloc_init() succeeded!\n");  // 打印初始化成功信息
}

/**
 * @brief 获取小内存块已分配大小（本实现未实际统计，返回0）
 * @return 已分配大小（字节）
 */
size_t
slob_allocated(void)
{
    return 0;
}

/**
 * @brief 获取全局已分配内存大小（对外接口）
 * @return 已分配大小（字节）
 */
size_t
kallocated(void)
{
    return slob_allocated();
}

/**
 * @brief 计算大内存块所需的页级数
 * @param size 需求大小（字节）
 * @return 页级数order（分配页数 = 2^order，且2^order * PAGE_SIZE >= size）
 */
static int find_order(int size)
{
    int order = 0;
    // 计算最小的order，使得2^order * PAGE_SIZE >= size
    for (; size > 4096; size >>= 1)
        order++;
    return order;
}

/**
 * @brief kmalloc核心实现（区分大小对象分配）
 * @param size 需求大小（字节）
 * @param gfp 分配标志（未使用）
 * @return 成功：分配的内存虚拟地址；失败：NULL
 */
static void *__kmalloc(size_t size, gfp_t gfp)
{
    slob_t *m;         // 小内存块指针
    bigblock_t *bb;    // 大内存块指针
    unsigned long flags;

    // 小对象分配：大小 < PAGE_SIZE - 块头部大小（避免跨页）
    if (size < PAGE_SIZE - SLOB_UNIT)
    {
        // 分配时预留SLOB_UNIT大小的头部（存储units信息）
        m = slob_alloc(size + SLOB_UNIT, gfp, 0);
        // 返回时跳过头部，给用户返回实际可用地址
        return m ? (void *)(m + 1) : 0;
    }

    // 大对象分配：大小 >= PAGE_SIZE
    // 1. 先分配大内存块的管理结构体（从属于小内存块分配）
    bb = slob_alloc(sizeof(bigblock_t), gfp, 0);
    if (!bb)
        return 0;

    // 2. 计算所需页级数并分配连续物理页
    bb->order = find_order(size);
    bb->pages = (void *)__slob_get_free_pages(gfp, bb->order);

    if (bb->pages)
    {
        // 3. 将大内存块加入全局链表（临界区保护）
        spin_lock_irqsave(&block_lock, flags);
        bb->next = bigblocks;
        bigblocks = bb;
        spin_unlock_irqrestore(&block_lock, flags);
        return bb->pages;  // 返回大对象的实际地址
    }

    // 物理页分配失败，释放管理结构体并返回NULL
    slob_free(bb, sizeof(bigblock_t));
    return 0;
}

/**
 * @brief 内核内存分配对外接口
 * @param size 需求大小（字节）
 * @return 成功：分配的内存虚拟地址；失败：NULL
 */
void *
kmalloc(size_t size)
{
    return __kmalloc(size, 0);
}

/**
 * @brief 内核内存释放对外接口（自动区分大小对象）
 * @param block 待释放的内存地址
 */
void kfree(void *block)
{
    bigblock_t *bb, **last = &bigblocks;  // last：大内存块链表的前驱指针
    unsigned long flags;

    if (!block)
        return;  // 空指针直接返回

    // 检查地址是否页对齐（大对象的特征）
    if (!((unsigned long)block & (PAGE_SIZE - 1)))
    {
        // 尝试在大内存块链表中查找
        spin_lock_irqsave(&block_lock, flags);
        for (bb = bigblocks; bb; last = &bb->next, bb = bb->next)
        {
            if (bb->pages == block)
            {
                // 找到匹配的大内存块：从链表中移除
                *last = bb->next;
                spin_unlock_irqrestore(&block_lock, flags);
                // 释放对应的物理页和管理结构体
                __slob_free_pages((unsigned long)block, bb->order);
                slob_free(bb, sizeof(bigblock_t));
                return;
            }
        }
        spin_unlock_irqrestore(&block_lock, flags);
    }

    // 小对象释放：跳过用户地址，释放对应的slob_t块（包含头部）
    slob_free((slob_t *)block - 1, 0);
    return;
}

/**
 * @brief 获取已分配内存块的实际大小（对外接口）
 * @param block 内存块地址
 * @return 实际分配的大小（字节）
 */
unsigned int ksize(const void *block)
{
    bigblock_t *bb;
    unsigned long flags;

    if (!block)
        return 0;  // 空指针返回0

    // 检查地址是否页对齐（大对象特征）
    if (!((unsigned long)block & (PAGE_SIZE - 1)))
    {
        // 在大内存块链表中查找
        spin_lock_irqsave(&block_lock, flags);
        for (bb = bigblocks; bb; bb = bb->next)
            if (bb->pages == block)
            {
                spin_unlock_irqrestore(&block_lock, flags);
                // 大对象大小 = 2^order * PAGE_SIZE
                return PAGE_SIZE << bb->order;
            }
        spin_unlock_irqrestore(&block_lock, flags);
    }

    // 小对象大小：从块头部的units字段计算（units * SLOB_UNIT）
    return ((slob_t *)block - 1)->units * SLOB_UNIT;
}