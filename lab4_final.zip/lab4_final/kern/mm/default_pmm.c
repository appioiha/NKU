#include <pmm.h>
#include <list.h>
#include <string.h>
#include <default_pmm.h>

/* 
 * 首次适配算法(First-Fit Memory Allocation, FFMA)原理说明：
 * 1. 维护一个空闲内存块链表（空闲链表），记录所有可用的连续内存页
 * 2. 当收到内存分配请求时，从链表头部开始扫描，找到第一个大小满足需求的空闲块
 * 3. 若找到的块远大于需求，将其拆分：分配部分给请求，剩余部分仍作为空闲块保留在链表中
 * 参考：严蔚敏《数据结构（C语言版）》第8.2节 196~198页
 */
// LAB2 要求：重写以下核心函数：default_init, default_init_memmap, default_alloc_pages, default_free_pages

/*
 * FFMA实现细节说明：
 * (1) 准备工作：需用链表管理空闲块，free_area_t结构体用于空闲内存块管理
 *              需熟悉list.h中的双向链表操作：list_init, list_add, list_del等
 *              关键技巧：通过le2page宏（memlayout.h）将通用链表节点转换为Page结构体指针
 * (2) default_init：初始化空闲链表和空闲页计数器
 * (3) default_init_memmap：初始化指定地址范围的内存块为空闲状态
 * (4) default_alloc_pages：从空闲链表中查找首个满足大小的块，分配并拆分（若需）
 * (5) default_free_pages：释放内存页，重新加入空闲链表，并尝试合并相邻空闲块
 */

// 空闲内存块管理结构体：包含空闲链表和空闲页总数
free_area_t free_area;

// 宏定义：简化空闲链表和空闲页计数的访问
#define free_list (free_area.free_list)  // 空闲链表：存储所有连续的空闲内存块
#define nr_free (free_area.nr_free)      // 空闲页总数：记录系统中可用的内存页数量

/**
 * @brief 初始化内存分配器
 * 功能：初始化空闲链表和空闲页计数器，为后续内存管理做准备
 */
static void
default_init(void) {
    list_init(&free_list);  // 初始化空闲链表（双向链表初始化）
    nr_free = 0;            // 初始时无空闲页，计数器置0
}

/**
 * @brief 初始化指定地址范围的内存块为空闲状态
 * @param base 内存块的起始页指针（Page结构体指针）
 * @param n 该内存块包含的连续页数
 * 调用链路：kern_init --> pmm_init --> page_init --> init_memmap --> 此函数
 */
static void
default_init_memmap(struct Page *base, size_t n) {
    assert(n > 0);  // 确保初始化的页数大于0
    struct Page *p = base;
    // 遍历该内存块的每一页，初始化页属性
    for (; p != base + n; p++) {
        assert(PageReserved(p));  // 确保当前页已被标记为"保留"（内核初始化时设置）
        
        p->flags = 0;             // 重置页标志位
        SetPageProperty(p);       // 设置PG_property标志：表示该页为有效空闲页
        p->property = 0;          // 初始化页的块大小属性（非首页暂设为0）
        set_page_ref(p, 0);       // 页引用计数置0（空闲页无引用）
    }
    // 标记该空闲块的首页：记录整个块的页数
    base->property = n;
    SetPageProperty(base);       // 确保首页的PG_property标志已设置
    nr_free += n;                // 累加系统空闲页总数

    // 将新初始化的空闲块插入空闲链表（按地址升序插入）
    if (list_empty(&free_list)) {
        // 若链表为空，直接插入链表
        list_add(&free_list, &(base->page_link));
    } else {
        list_entry_t *le = &free_list;
        // 遍历链表，找到插入位置（插入到第一个地址大于base的块之前）
        while ((le = list_next(le)) != &free_list) {
            struct Page *page = le2page(le, page_link);
            if (base < page) {
                list_add_before(le, &(base->page_link));
                break;
            } else if (list_next(le) == &free_list) {
                // 若遍历到链表末尾，插入到最后
                list_add(le, &(base->page_link));
            }
        }
    }
}

/**
 * @brief 分配n个连续的内存页
 * @param n 需求的连续页数
 * @return 成功：返回分配到的内存块首页指针；失败：返回NULL
 */
static struct Page *
default_alloc_pages(size_t n) {
    assert(n > 0);  // 确保分配页数大于0
    if (n > nr_free) {
        return NULL;  // 空闲页总数不足，分配失败
    }

    struct Page *page = NULL;  // 存储找到的空闲块首页
    list_entry_t *le = &free_list;

    // 遍历空闲链表，查找第一个大小满足n的空闲块（首次适配核心逻辑）
    while ((le = list_next(le)) != &free_list) {
        struct Page *p = le2page(le, page_link);  // 链表节点转换为Page指针
        if (p->property >= n) {  // 找到满足大小的空闲块
            page = p;
            break;
        }
    }

    // 若找到可用空闲块，处理分配逻辑
    if (page != NULL) {
        list_entry_t *prev_le = list_prev(&(page->page_link));  // 记录前驱节点
        list_del(&(page->page_link));  // 将该块从空闲链表中移除

        // 若空闲块大小大于需求，拆分块并保留剩余部分
        if (page->property > n) {
            struct Page *remain_page = page + n;  // 剩余块的首页
            remain_page->property = page->property - n;  // 剩余块的页数
            SetPageProperty(remain_page);  // 标记剩余块为空闲
            list_add(prev_le, &(remain_page->page_link));  // 剩余块插回空闲链表
        }

        nr_free -= n;  // 空闲页总数减少n
        ClearPageProperty(page);  // 清除PG_property标志：标记该块已被分配
    }

    return page;  // 返回分配到的块首页
}

/**
 * @brief 释放n个连续的内存页
 * @param base 待释放内存块的首页指针
 * @param n 待释放的连续页数
 * 功能：将释放的页重新加入空闲链表，并尝试合并相邻的空闲块（减少碎片）
 */
static void
default_free_pages(struct Page *base, size_t n) {
    assert(n > 0);  // 确保释放页数大于0
    struct Page *p = base;
    // 遍历待释放的每一页，重置页属性
    for (; p != base + n; p++) {
        // 确保该页未被保留且未被标记为空闲（避免重复释放）
        assert(!PageReserved(p) && !PageProperty(p));
        p->flags = 0;             // 重置标志位
        set_page_ref(p, 0);       // 引用计数置0
    }
    // 标记释放块的首页：记录块大小
    base->property = n;
    SetPageProperty(base);       // 标记为空闲块
    nr_free += n;                // 空闲页总数增加n

    // 将释放的块插入空闲链表（按地址升序）
    if (list_empty(&free_list)) {
        list_add(&free_list, &(base->page_link));
    } else {
        list_entry_t *le = &free_list;
        while ((le = list_next(le)) != &free_list) {
            struct Page *page = le2page(le, page_link);
            if (base < page) {
                list_add_before(le, &(base->page_link));
                break;
            } else if (list_next(le) == &free_list) {
                list_add(le, &(base->page_link));
            }
        }
    }

    // 尝试合并【当前块与前驱块】（若地址连续）
    list_entry_t *le = list_prev(&(base->page_link));
    if (le != &free_list) {  // 存在前驱块
        p = le2page(le, page_link);
        // 前驱块的末尾地址 == 当前块的起始地址（地址连续）
        if (p + p->property == base) {
            p->property += base->property;  // 合并块大小
            ClearPageProperty(base);        // 清除当前块的首页标记
            list_del(&(base->page_link));   // 从链表中删除当前块节点
            base = p;                       // 更新合并后的块首页
        }
    }

    // 尝试合并【当前块与后继块】（若地址连续）
    le = list_next(&(base->page_link));
    if (le != &free_list) {  // 存在后继块
        p = le2page(le, page_link);
        // 当前块的末尾地址 == 后继块的起始地址（地址连续）
        if (base + base->property == p) {
            base->property += p->property;  // 合并块大小
            ClearPageProperty(p);           // 清除后继块的首页标记
            list_del(&(p->page_link));      // 从链表中删除后继块节点
        }
    }
}

/**
 * @brief 获取当前系统的空闲页总数
 * @return 空闲页数量
 */
static size_t
default_nr_free_pages(void) {
    return nr_free;
}

/**
 * @brief 基础功能检查函数
 * 功能：验证内存分配、释放的基本正确性（如分配非空、释放后计数正确等）
 * 注意：禁止修改此函数
 */
static void
basic_check(void) {
    struct Page *p0, *p1, *p2;
    p0 = p1 = p2 = NULL;
    assert((p0 = alloc_page()) != NULL);  // 分配1页，验证非空
    assert((p1 = alloc_page()) != NULL);
    assert((p2 = alloc_page()) != NULL);

    assert(p0 != p1 && p0 != p2 && p1 != p2);  // 验证分配的页地址不同
    assert(page_ref(p0) == 0 && page_ref(p1) == 0 && page_ref(p2) == 0);  // 引用计数为0

    // 验证页的物理地址在合法范围内
    assert(page2pa(p0) < npage * PGSIZE);
    assert(page2pa(p1) < npage * PGSIZE);
    assert(page2pa(p2) < npage * PGSIZE);

    // 临时保存空闲链表和计数，进行独立测试
    list_entry_t free_list_store = free_list;
    list_init(&free_list);
    assert(list_empty(&free_list));  // 链表为空

    unsigned int nr_free_store = nr_free;
    nr_free = 0;

    assert(alloc_page() == NULL);  // 无空闲页时分配失败

    // 释放页后验证计数
    free_page(p0);
    free_page(p1);
    free_page(p2);
    assert(nr_free == 3);

    // 重新分配验证
    assert((p0 = alloc_page()) != NULL);
    assert((p1 = alloc_page()) != NULL);
    assert((p2 = alloc_page()) != NULL);
    assert(alloc_page() == NULL);  // 分配完所有空闲页

    // 单页释放与分配验证
    free_page(p0);
    assert(!list_empty(&free_list));
    struct Page *p;
    assert((p = alloc_page()) == p0);  // 分配刚释放的页
    assert(alloc_page() == NULL);

    // 恢复原始状态
    assert(nr_free == 0);
    free_list = free_list_store;
    nr_free = nr_free_store;

    free_page(p);
    free_page(p1);
    free_page(p2);
}

/**
 * @brief 首次适配算法专项检查函数
 * 功能：验证分配、拆分、合并等核心逻辑的正确性
 * 注意：禁止修改此函数
 */
static void
default_check(void) {
    int count = 0, total = 0;
    // 验证空闲链表中的块总数与空闲页总数一致
    list_entry_t *le = &free_list;
    while ((le = list_next(le)) != &free_list) {
        struct Page *p = le2page(le, page_link);
        assert(PageProperty(p));  // 所有链表节点均为空闲块首页
        count++, total += p->property;
    }
    assert(total == nr_free_pages());

    basic_check();  // 执行基础检查

    // 测试多页分配与拆分
    struct Page *p0 = alloc_pages(5), *p1, *p2;
    assert(p0 != NULL);
    assert(!PageProperty(p0));  // 已分配块不标记为空闲

    // 临时清空空闲链表，测试独立场景
    list_entry_t free_list_store = free_list;
    list_init(&free_list);
    assert(list_empty(&free_list));
    assert(alloc_page() == NULL);

    unsigned int nr_free_store = nr_free;
    nr_free = 0;

    // 释放部分页，验证拆分后的块
    free_pages(p0 + 2, 3);
    assert(alloc_pages(4) == NULL);  // 3页不足以分配4页
    assert(PageProperty(p0 + 2) && p0[2].property == 3);
    assert((p1 = alloc_pages(3)) != NULL);
    assert(alloc_page() == NULL);
    assert(p0 + 2 == p1);  // 分配的是刚释放的3页

    // 测试块合并
    p2 = p0 + 1;
    free_page(p0);
    free_pages(p1, 3);
    assert(PageProperty(p0) && p0->property == 1);  // 单独释放的1页
    assert(PageProperty(p1) && p1->property == 3);  // 释放的3页

    // 验证分配顺序（首次适配）
    assert((p0 = alloc_page()) == p2 - 1);  // 分配p0（地址靠前的块）
    free_page(p0);
    assert((p0 = alloc_pages(2)) == p2 + 1);  // 分配连续的2页

    // 释放后验证合并
    free_pages(p0, 2);
    free_page(p2);
    assert((p0 = alloc_pages(5)) != NULL);  // 合并后可分配5页
    assert(alloc_page() == NULL);

    // 恢复原始状态
    assert(nr_free == 0);
    nr_free = nr_free_store;
    free_list = free_list_store;
    free_pages(p0, 5);

    // 验证最终空闲链表状态
    le = &free_list;
    while ((le = list_next(le)) != &free_list) {
        struct Page *p = le2page(le, page_link);
        count--, total -= p->property;
    }
    assert(count == 0);
    assert(total == 0);
}

// 内存分配器管理器结构体：注册首次适配算法的各项接口
const struct pmm_manager default_pmm_manager = {
    .name = "default_pmm_manager",        // 分配器名称
    .init = default_init,                 // 初始化接口
    .init_memmap = default_init_memmap,   // 内存块初始化接口
    .alloc_pages = default_alloc_pages,   // 分配接口
    .free_pages = default_free_pages,     // 释放接口
    .nr_free_pages = default_nr_free_pages, // 空闲页计数接口
    .check = default_check,               // 正确性检查接口
};