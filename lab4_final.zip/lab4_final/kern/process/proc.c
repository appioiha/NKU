#include <proc.h>
#include <kmalloc.h>
#include <string.h>
#include <sync.h>
#include <pmm.h>
#include <error.h>
#include <sched.h>
#include <elf.h>
#include <vmm.h>
#include <<trap.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

/* ------------- 进程/线程机制设计与实现 -------------
(简化的Linux进程/线程模型)
核心说明：
ucore的进程包含独立内存空间、至少一个执行线程、内核管理数据、处理器状态等；
线程是特殊的进程——共享所属进程的内存空间，仅保留独立执行状态，是调度基本单位。

------------------------------
进程状态定义：状态含义及触发条件
    PROC_UNINIT     : 未初始化状态   -- 调用alloc_proc分配PCB后
    PROC_SLEEPING   : 睡眠状态      -- 调用try_free_pages/do_wait/do_sleep
    PROC_RUNNABLE   : 就绪状态(可能正在运行) -- 调用proc_init/wakeup_proc
    PROC_ZOMBIE     : 僵尸状态      -- 调用do_exit后（等待父进程回收资源）

-----------------------------
进程状态流转：
  alloc_proc(分配PCB)                          运行中(RUNNING)
      +                                   +--<----<--+
      +                                   + proc_run(进程切换) +
      V                                   +-->---->--+
PROC_UNINIT -- proc_init/wakeup_proc --> PROC_RUNNABLE -- try_free_pages/do_wait/do_sleep --> PROC_SLEEPING --
                                           A      +                                                           +
                                           |      +--- do_exit --> PROC_ZOMBIE(僵尸)                          +
                                           +                                                                  +
                                           -----------------------wakeup_proc(唤醒)------------------------------
-----------------------------
进程间关系：
parent:           proc->parent  (当前进程是子进程)
children:         proc->cptr    (当前进程是父进程)
older sibling:    proc->optr    (当前进程是弟进程)
younger sibling:  proc->yptr    (当前进程是兄进程)
-----------------------------
进程相关系统调用映射：
SYS_exit        : 进程退出                           --> do_exit
SYS_fork        : 创建子进程（复制内存空间）          --> do_fork-->wakeup_proc
SYS_wait        : 等待子进程结束                      --> do_wait
SYS_exec        : 加载并执行新程序（刷新内存空间）    --> 加载程序+更新mm结构
SYS_clone       : 创建线程（共享内存空间）            --> do_fork-->wakeup_proc
SYS_yield       : 主动放弃CPU（标记需要调度）         --> 设置proc->need_sched=1
SYS_sleep       : 进程睡眠                           --> do_sleep
SYS_kill        : 终止进程                           --> do_kill-->设置proc->flags|=PF_EXITING-->唤醒父进程-->do_wait-->do_exit
SYS_getpid      : 获取进程PID                        --> 读取proc->pid
*/

// 所有进程的全局链表（管理系统中所有进程）
list_entry_t proc_list;

// PID哈希表配置：哈希移位位数、哈希表大小、哈希函数
#define HASH_SHIFT 10
#define HASH_LIST_SIZE (1 << HASH_SHIFT)  // 哈希表大小=2^10=1024
#define pid_hashfn(x) (hash32(x, HASH_SHIFT))  // 32位哈希函数，生成哈希表索引

// 基于PID的进程哈希链表（快速查找进程，优化PID查询效率）
static list_entry_t hash_list[HASH_LIST_SIZE];

// 空闲进程（PID=0，系统无就绪进程时运行）
struct proc_struct *idleproc = NULL;
// 初始化进程（PID=1，第一个执行实际任务的内核线程）
struct proc_struct *initproc = NULL;
// 当前正在CPU上运行的进程
struct proc_struct *current = NULL;

// 系统中进程总数（包括所有状态的进程）
static int nr_process = 0;

// 外部函数声明（汇编实现或其他文件实现）
void kernel_thread_entry(void);  // 内核线程入口（汇编函数）
void forkrets(struct trapframe *tf);  // 进程fork后的用户态恢复函数
void switch_to(struct context *from, struct context *to);  // 进程上下文切换（汇编函数）

/**
 * @brief 分配并初始化进程控制块（PCB）
 * @return 成功：初始化后的PCB指针；失败：NULL
 * 功能：通过kmalloc分配PCB内存，初始化所有字段为安全状态，避免未初始化内存导致异常
 */
static struct proc_struct *
alloc_proc(void)
{
    // 分配struct proc_struct大小的内存（PCB内存）
    struct proc_struct *proc = kmalloc(sizeof(struct proc_struct));
    if (proc != NULL)
    {
        // LAB4:EXERCISE1 2313650（组员编号标记）
        /* 需初始化的PCB字段说明：
         * enum proc_state state;          // 进程状态
         * int pid;                        // 进程ID
         * int runs;                       // 进程运行次数
         * uintptr_t kstack;               // 内核栈地址
         * volatile bool need_resched;     // 是否需要重新调度
         * struct proc_struct *parent;     // 父进程指针
         * struct mm_struct *mm;           // 内存管理结构（本实验未使用）
         * struct context context;         // 进程上下文（切换用）
         * struct trapframe *tf;           // 陷阱帧（保存中断/异常现场）
         * uintptr_t pgdir;                // 页目录物理地址
         * uint32_t flags;                 // 进程标志
         * char name[PROC_NAME_LEN + 1];   // 进程名
         */
        proc->state = PROC_UNINIT;    // 进程状态：未初始化
        proc->pid = -1;               // PID：-1表示未分配
        proc->runs = 0;               // 运行次数：初始为0
        proc->kstack = 0;             // 内核栈地址：初始为0（未分配）
        proc->need_resched = 0;       // 不需要重新调度（初始状态）
        proc->parent = NULL;          // 父进程：无（初始为NULL）
        proc->mm = NULL;              // 内存管理结构：NULL（内核线程无需独立内存空间）
        // 进程上下文清零（寄存器状态初始化为0）
        memset(&(proc->context), 0, sizeof(struct context));
        proc->tf = NULL;              // 陷阱帧：NULL（未发生中断/异常）
        proc->pgdir = boot_pgdir_pa;  // 页目录：使用内核页目录（内核线程共享内核地址空间）
        proc->flags = 0;              // 进程标志：初始为0
        // 进程名清零（避免垃圾数据）
        memset(proc->name, 0, PROC_NAME_LEN + 1);
    }
    return proc;  // 返回初始化后的PCB
}

/**
 * @brief 设置进程名称
 * @param proc 目标进程的PCB指针
 * @param name 要设置的进程名（字符串）
 * @return 设置后的进程名字符串
 * 功能：安全设置进程名，确保不超过PROC_NAME_LEN长度
 */
char *
set_proc_name(struct proc_struct *proc, const char *name)
{
    memset(proc->name, 0, sizeof(proc->name));  // 进程名字段清零
    // 复制name到进程名（最多复制PROC_NAME_LEN个字符，避免越界）
    return memcpy(proc->name, name, PROC_NAME_LEN);
}

/**
 * @brief 获取进程名称
 * @param proc 目标进程的PCB指针
 * @return 进程名的副本（静态字符串，需及时使用）
 * 功能：安全读取进程名，避免直接访问PCB字段导致的越界
 */
char *
get_proc_name(struct proc_struct *proc)
{
    static char name[PROC_NAME_LEN + 1];  // 静态缓冲区（避免栈溢出）
    memset(name, 0, sizeof(name));        // 缓冲区清零
    memcpy(name, proc->name, PROC_NAME_LEN);  // 复制进程名
    return name;
}

/**
 * @brief 分配全局唯一的PID
 * @return 唯一的PID（范围：1~MAX_PID-1）
 * 功能：通过遍历进程列表确保PID唯一性，支持PID回绕（避免PID耗尽）
 */
static int
get_pid(void)
{
    static_assert(MAX_PID > MAX_PROCESS);  // 断言：最大PID大于最大进程数（确保PID够用）
    struct proc_struct *proc;
    list_entry_t *list = &proc_list, *le;
    // 静态变量：下次安全检查点（优化遍历效率）、上次分配的PID
    static int next_safe = MAX_PID, last_pid = MAX_PID;
    
    // PID自增，超过MAX_PID则回绕到1
    if (++last_pid >= MAX_PID)
    {
        last_pid = 1;
        goto inside;
    }
    // 若当前PID超过下次安全检查点，需重新遍历进程列表
    if (last_pid >= next_safe)
    {
    inside:
        next_safe = MAX_PID;  // 重置下次安全检查点
    repeat:
        le = list;
        // 遍历所有进程，检查PID是否重复
        while ((le = list_next(le)) != list)
        {
            proc = le2proc(le, list_link);  // 链表节点转换为PCB指针
            if (proc->pid == last_pid)
            {
                // PID重复，自增后继续检查
                if (++last_pid >= next_safe)
                {
                    if (last_pid >= MAX_PID)
                    {
                        last_pid = 1;  // 回绕到1
                    }
                    next_safe = MAX_PID;
                    goto repeat;
                }
            }
            // 更新下次安全检查点（减少后续遍历范围）
            else if (proc->pid > last_pid && next_safe > proc->pid)
            {
                next_safe = proc->pid;
            }
        }
    }
    return last_pid;  // 返回唯一PID
}

/**
 * @brief 使目标进程在CPU上运行（进程切换核心函数）
 * @param proc 要运行的目标进程PCB指针
 * 功能：切换当前进程到目标进程，包括地址空间切换和上下文切换，关中断保证原子性
 */
void proc_run(struct proc_struct *proc)
{
    // 若目标进程不是当前进程，才需要切换（避免不必要的开销）
    if (proc != current)
    {
        // LAB4:EXERCISE3 2311576（组员编号标记）
        /* 可用宏/函数说明：
         * local_intr_save(): 禁用中断并保存中断状态
         * local_intr_restore(): 恢复中断状态
         * lsatp(): 修改satp寄存器（设置页目录，切换地址空间）
         * switch_to(): 上下文切换（保存当前进程状态，恢复目标进程状态）
         */
        bool intr_flag;  // 保存中断状态
        struct proc_struct *prev = current, *next = proc;  // 前一个进程、目标进程
        
        local_intr_save(intr_flag);  // 禁用中断（保证切换过程原子性，避免被中断干扰）
        {
            current = proc;  // 更新当前进程为目标进程
            
            lsatp(proc->pgdir);  // 切换页目录：修改satp寄存器，加载目标进程的地址空间
            
            switch_to(&(prev->context), &(next->context));  // 上下文切换：保存prev的寄存器状态，恢复next的寄存器状态
        }
        local_intr_restore(intr_flag);  // 恢复中断状态（切换完成，允许响应外部中断）
    }
}

/**
 * @brief 新进程/线程的内核态入口函数
 * 功能：进程切换后，目标进程从这里开始执行，最终调用forkrets恢复用户态（或内核线程入口）
 */
static void
forkret(void)
{
    forkrets(current->tf);  // 恢复陷阱帧，进入用户态（或内核线程的执行函数）
}

/**
 * @brief 将进程加入PID哈希链表
 * @param proc 要加入的进程PCB指针
 * 功能：根据PID计算哈希索引，将进程的hash_link节点加入对应哈希链表（优化查找）
 */
static void
hash_proc(struct proc_struct *proc)
{
    // 计算PID的哈希索引，将进程加入对应哈希链表
    list_add(hash_list + pid_hashfn(proc->pid), &(proc->hash_link));
}

/**
 * @brief 根据PID查找进程
 * @param pid 要查找的进程PID
 * @return 成功：对应的PCB指针；失败：NULL
 * 功能：通过PID哈希快速定位进程，避免遍历所有进程（提升查找效率）
 */
struct proc_struct *
find_proc(int pid)
{
    // PID需在有效范围（1~MAX_PID-1）
    if (0 < pid && pid < MAX_PID)
    {
        // 计算PID的哈希索引，获取对应的哈希链表
        list_entry_t *list = hash_list + pid_hashfn(pid), *le = list;
        // 遍历哈希链表，查找PID匹配的进程
        while ((le = list_next(le)) != list)
        {
            struct proc_struct *proc = le2proc(le, hash_link);
            if (proc->pid == pid)
            {
                return proc;  // 找到进程，返回PCB指针
            }
        }
    }
    return NULL;  // 未找到进程
}

/**
 * @brief 创建内核线程
 * @param fn 内核线程要执行的函数指针
 * @param arg 函数参数
 * @param clone_flags 克隆标志（控制内存共享/复制）
 * @return 成功：新线程的PID；失败：<=0
 * 功能：构造内核线程的陷阱帧，调用do_fork创建线程（内核线程共享内核地址空间）
 */
int kernel_thread(int (*fn)(void *), void *arg, uint32_t clone_flags)
{
    struct trapframe tf;  // 临时陷阱帧（用于初始化线程执行环境）
    memset(&tf, 0, sizeof(struct trapframe));  // 陷阱帧清零
    
    tf.gpr.s0 = (uintptr_t)fn;  // s0寄存器：存储线程函数指针
    tf.gpr.s1 = (uintptr_t)arg;  // s1寄存器：存储函数参数
    // 状态寄存器：设置SPP（超级模式）、SPIE（中断使能），清除SIE（当前禁用中断）
    tf.status = (read_csr(sstatus) | SSTATUS_SPP | SSTATUS_SPIE) & ~SSTATUS_SIE;
    tf.epc = (uintptr_t)kernel_thread_entry;  // 程序计数器：内核线程汇编入口地址
    
    // 调用do_fork创建线程：CLONE_VM表示共享内存（内核线程特性）
    return do_fork(clone_flags | CLONE_VM, 0, &tf);
}

/**
 * @brief 为进程分配内核栈
 * @param proc 目标进程的PCB指针
 * @return 成功：0；失败：-E_NO_MEM（内存不足）
 * 功能：分配KSTACKPAGE个连续物理页作为内核栈，记录栈地址到proc->kstack
 */
static int
setup_kstack(struct proc_struct *proc)
{
    // 分配KSTACKPAGE个连续物理页（默认1页，4KB）
    struct Page *page = alloc_pages(KSTACKPAGE);
    if (page != NULL)
    {
        proc->kstack = (uintptr_t)page2kva(page);  // 物理页转换为内核虚拟地址，存入kstack
        return 0;
    }
    return -E_NO_MEM;  // 内存不足，分配失败
}

/**
 * @brief 释放进程的内核栈
 * @param proc 目标进程的PCB指针
 * 功能：释放内核栈占用的物理页，避免内存泄漏
 */
static void
put_kstack(struct proc_struct *proc)
{
    // 将内核虚拟地址转换为Page指针，释放KSTACKPAGE个物理页
    free_pages(kva2page((void *)(proc->kstack)), KSTACKPAGE);
}

/**
 * @brief 复制或共享进程的内存管理结构
 * @param clone_flags 克隆标志（CLONE_VM表示共享，否则复制）
 * @param proc 子进程的PCB指针
 * @return 成功：0；失败：非0
 * 功能：本实验中内核线程共享内核地址空间，故仅返回0（无实际复制操作）
 */
static int
copy_mm(uint32_t clone_flags, struct proc_struct *proc)
{
    assert(current->mm == NULL);  // 断言：当前进程（父进程）无独立内存管理结构（内核线程）
    /* 本实验未实现用户态进程，故无实际内存复制逻辑 */
    return 0;
}

/**
 * @brief 设置进程的陷阱帧和上下文（为进程切换做准备）
 * @param proc 目标进程的PCB指针
 * @param esp 用户栈指针（内核线程为0）
 * @param tf 父进程的陷阱帧（用于复制执行环境）
 * 功能：在进程内核栈顶部构造陷阱帧，初始化上下文的返回地址和栈指针
 */
static void
copy_thread(struct proc_struct *proc, uintptr_t esp, struct trapframe *tf)
{
    // 陷阱帧位置：内核栈顶部（KSTACKSIZE - 陷阱帧大小），避免栈溢出
    proc->tf = (struct trapframe *)(proc->kstack + KSTACKSIZE - sizeof(struct trapframe));
    *(proc->tf) = *tf;  // 复制父进程的陷阱帧（继承执行环境）

    proc->tf->gpr.a0 = 0;  // 设置a0寄存器为0：子进程通过a0判断自己是fork创建的
    // 设置栈指针：内核线程（esp=0）使用陷阱帧地址作为栈指针，用户进程使用传入的esp
    proc->tf->gpr.sp = (esp == 0) ? (uintptr_t)proc->tf : esp;

    proc->context.ra = (uintptr_t)forkret;  // 上下文返回地址：forkret（进程切换后的入口）
    proc->context.sp = (uintptr_t)(proc->tf);  // 上下文栈指针：陷阱帧地址（内核栈顶部）
}

/**
 * @brief 创建新进程/线程（fork系统调用核心实现）
 * @param clone_flags 克隆标志（控制内存共享/复制、线程/进程创建）
 * @param stack 用户栈指针（内核线程为0）
 * @param tf 父进程的陷阱帧（用于子进程执行环境初始化）
 * @return 成功：子进程PID；失败：错误码（<0）
 * 功能：为新进程分配PCB、内核栈、初始化上下文，加入进程列表，设置为就绪状态
 */
int do_fork(uint32_t clone_flags, uintptr_t stack, struct trapframe *tf)
{
    int ret = -E_NO_FREE_PROC;  // 初始错误码：无空闲进程（进程数达到上限）
    struct proc_struct *proc;
    // 检查进程数是否超过上限（MAX_PROCESS）
    if (nr_process >= MAX_PROCESS)
    {
        goto fork_out;  // 跳转至函数末尾返回
    }
    ret = -E_NO_MEM;  // 更新错误码：内存不足

    // LAB4:EXERCISE2 2311858（组员编号标记）
    /* 可用宏/函数说明：
     * alloc_proc: 分配并初始化PCB（实验1实现）
     * setup_kstack: 为子进程分配内核栈
     * copy_mm: 共享/复制内存管理结构
     * copy_thread: 初始化子进程的陷阱帧和上下文
     * hash_proc: 将子进程加入PID哈希链表
     * get_pid: 分配唯一PID
     * wakeup_proc: 将子进程设为就绪状态
     * 全局变量：
     *   proc_list: 所有进程的链表
     *   nr_process: 进程总数
     */

    // 1. 分配并初始化PCB
    proc = alloc_proc();
    if (proc == NULL) {
        goto fork_out;  // PCB分配失败，返回
    }

    // 2. 为子进程分配内核栈
    if (setup_kstack(proc) != 0) {
        goto bad_fork_cleanup_proc;  // 内核栈分配失败，释放PCB
    }

    // 3. 根据克隆标志，共享或复制内存管理结构
    if (copy_mm(clone_flags, proc) != 0) {
        goto bad_fork_cleanup_kstack;  // 内存管理结构处理失败，释放内核栈和PCB
    }

    // 4. 初始化子进程的陷阱帧和上下文
    copy_thread(proc, stack, tf);

    // 5. 将子进程加入哈希链表和进程全局链表（关中断保护临界区）
    bool intr_flag;
    local_intr_save(intr_flag);  // 禁用中断，避免并发访问导致链表错乱
    {
        proc->pid = get_pid();  // 分配唯一PID
        hash_proc(proc);  // 加入PID哈希链表
        list_add(&proc_list, &(proc->list_link));  // 加入进程全局链表
        nr_process++;  // 进程总数+1
    }
    local_intr_restore(intr_flag);  // 恢复中断

    // 6. 唤醒子进程，设置为就绪状态（等待调度执行）
    wakeup_proc(proc);

    // 7. 设置返回值为子进程PID（父进程视角）
    ret = proc->pid;
    
fork_out:
    return ret;  // 返回PID或错误码

// 错误处理：释放内核栈
bad_fork_cleanup_kstack:
    put_kstack(proc);
// 错误处理：释放PCB
bad_fork_cleanup_proc:
    kfree(proc);
    goto fork_out;
}

/**
 * @brief 进程退出（exit系统调用实现）
 * @param error_code 退出错误码（未使用）
 * @return 无返回（进程退出后不会返回）
 * 功能：本实验仅打印panic信息，实际OS中需释放进程资源、通知父进程回收
 */
int do_exit(int error_code)
{
    panic("process exit!!.\n");  // 打印退出信息，内核终止
}

/**
 * @brief 初始化进程的执行函数（第二个内核线程）
 * @param arg 传入的参数（本实验为"Hello world!!"）
 * @return 退出码（0）
 * 功能：打印进程信息和问候语，是第一个执行实际任务的内核线程
 */
static int
init_main(void *arg)
{
    // 打印当前进程（initproc）的PID和名称
    cprintf("this initproc, pid = %d, name = \"%s\"\n", current->pid, get_proc_name(current));
    cprintf("To U: \"%s\".\n", (const char *)arg);  // 打印传入的问候语
    cprintf("To U: \"en.., Bye, Bye. :)\"\n");  // 打印告别语
    return 0;  // 返回退出码
}

/**
 * @brief 进程管理模块初始化（系统启动时调用）
 * 功能：初始化进程链表和哈希表，创建idleproc（空闲进程）和initproc（初始化进程）
 */
void proc_init(void)
{
    int i;

    list_init(&proc_list);  // 初始化进程全局链表
    // 初始化PID哈希表的每个链表节点
    for (i = 0; i < HASH_LIST_SIZE; i++)
    {
        list_init(hash_list + i);
    }

    // 分配并初始化idleproc（空闲进程）
    if ((idleproc = alloc_proc()) == NULL)
    {
        panic("cannot alloc idleproc.\n");  // 分配失败，内核终止
    }

    // 验证alloc_proc的初始化正确性（检查PCB字段是否符合预期）
    int *context_mem = (int *)kmalloc(sizeof(struct context));
    memset(context_mem, 0, sizeof(struct context));
    // 检查上下文是否清零
    int context_init_flag = memcmp(&(idleproc->context), context_mem, sizeof(struct context));

    int *proc_name_mem = (int *)kmalloc(PROC_NAME_LEN);
    memset(proc_name_mem, 0, PROC_NAME_LEN);
    // 检查进程名是否清零
    int proc_name_flag = memcmp(&(idleproc->name), proc_name_mem, PROC_NAME_LEN);

    // 验证PCB关键字段的初始化状态
    if (idleproc->pgdir == boot_pgdir_pa && idleproc->tf == NULL && !context_init_flag && 
        idleproc->state == PROC_UNINIT && idleproc->pid == -1 && idleproc->runs == 0 && 
        idleproc->kstack == 0 && idleproc->need_resched == 0 && idleproc->parent == NULL && 
        idleproc->mm == NULL && idleproc->flags == 0 && !proc_name_flag)
    {
        cprintf("alloc_proc() correct!\n");  // 初始化正确，打印提示
    }

    // 初始化idleproc的核心字段
    idleproc->pid = 0;  // PID=0（空闲进程固定PID）
    idleproc->state = PROC_RUNNABLE;  // 状态设为就绪
    idleproc->kstack = (uintptr_t)bootstack;  // 内核栈使用启动栈（bootstack）
    idleproc->need_resched = 1;  // 标记需要重新调度（触发调度器选择其他进程）
    set_proc_name(idleproc, "idle");  // 进程名设为"idle"
    nr_process++;  // 进程总数+1

    current = idleproc;  // 当前进程设为idleproc（系统启动后首先运行）

    // 创建initproc（初始化进程）：调用kernel_thread创建内核线程
    int pid = kernel_thread(init_main, "Hello world!!", 0);
    if (pid <= 0)
    {
        panic("create init_main failed.\n");  // 创建失败，内核终止
    }

    initproc = find_proc(pid);  // 根据PID查找initproc的PCB
    set_proc_name(initproc, "init");  // 进程名设为"init"

    // 断言：idleproc和initproc创建成功且PID正确
    assert(idleproc != NULL && idleproc->pid == 0);
    assert(initproc != NULL && initproc->pid == 1);
}

/**
 * @brief 空闲进程的执行函数（idleproc）
 * 功能：系统无就绪进程时循环等待，检测到需要调度时触发调度器
 */
void cpu_idle(void)
{
    while (1)  // 无限循环（空闲进程不会退出）
    {
        // 若当前进程（idleproc）标记为需要重新调度
        if (current->need_resched)
        {
            schedule();  // 调用调度器，选择下一个就绪进程
        }
    }
}