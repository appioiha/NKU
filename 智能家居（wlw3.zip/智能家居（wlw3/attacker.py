import paho.mqtt.client as mqtt
import time
import hmac
import hashlib
import uuid

MQTT_BROKER = "localhost"
BIND_RESULT_TOPIC = "user/bind_result"
bound_dev_id = None  # 绑定成功的设备ID
device_secret = ""   # 设备密钥（绑定成功后记录）


def on_message(client, userdata, msg):
    global bound_dev_id, device_secret
    if msg.topic == BIND_RESULT_TOPIC:
        result = msg.payload.decode()
        print(f"\n{result}")
        # 绑定成功，记录设备ID和密钥
        if "绑定成功" in result:
            bound_dev_id = result.split(" ")[0]
            print(f"\n✅ 已成功绑定 {bound_dev_id}，可开始控制！")


# 启动客户端
client = mqtt.Client()
client.on_message = on_message
client.connect(MQTT_BROKER, 1883, 60)
client.subscribe(BIND_RESULT_TOPIC)
client.subscribe("device/#")
client.loop_start()


# 步骤1：绑定设备
print("=== 攻击者绑定设备 ===")
dev_id = input("输入要绑定的设备ID（如aircon）：")
key = input("输入该设备的密钥：")
device_secret = key  # 记录密钥
client.publish(f"device/{dev_id}/bind", key)
print(f"正在尝试绑定 {dev_id}...")


# 步骤2：控制设备
while True:
    if bound_dev_id:
        print(f"\n=== 控制 {bound_dev_id} ===")
        cmd = input("输入指令（on/off/quit）：")
        if cmd == "quit":
            break
        elif cmd in ["on", "off"]:
            # 生成完整指令（指令|时间戳|随机数|签名）
            timestamp = str(int(time.time() * 1000))
            nonce = str(uuid.uuid4())[:8]
            content = f"{cmd}|{timestamp}|{nonce}".encode()
            signature = hmac.new(device_secret.encode(), content, hashlib.sha256).hexdigest()
            full_cmd = f"{cmd}|{timestamp}|{nonce}|{signature}"
            
            client.publish(f"device/{bound_dev_id}/control", full_cmd)
            print(f"已发送指令：{full_cmd}")
        else:
            print("无效指令！请输入on/off/quit")
    time.sleep(1)