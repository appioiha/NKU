import paho.mqtt.client as mqtt
import time
import hmac
import hashlib
import uuid

# 配置
MQTT_BROKER = "localhost"
USER_NAME = "user1"
DEVICES = {
    "aircon": b"aircon_key",
    "bulb": b"bulb_key",
    "socket": b"socket_key"
}
REGISTERED_DEVICES = []  # 已注册设备
BOUND_DEVICES = []       # 已绑定设备
DEVICE_PERMISSIONS = {}  # 设备权限


def on_message(client, userdata, msg):
    # 处理注册结果
    if msg.topic == "user/register_result":
        result = msg.payload.decode()
        print(f"\n注册结果：{result}")
        REGISTERED_DEVICES.append(result.split(" ")[0])
    # 处理绑定结果
    elif msg.topic == "user/bind_result":
        result = msg.payload.decode()
        print(f"\n绑定结果：{result}")
        BOUND_DEVICES.append(result.split(" ")[0])
    # 处理设备分享（自动注册+绑定）
    elif "share" in msg.topic:
        parts = msg.payload.decode().split("|")
        if parts[0] == "share" and len(parts) == 5:
            dev_id = parts[1]
            dev_key = parts[2].encode()
            permission = parts[3]
            is_registered = parts[4] == "True"
            
            DEVICES[dev_id] = dev_key
            DEVICE_PERMISSIONS[dev_id] = permission
            if is_registered:
                REGISTERED_DEVICES.append(dev_id)
                bind_device(dev_id)
                print(f"\n✅ 收到分享设备：{dev_id}（自动注册+绑定，权限：{permission}）")
            else:
                print(f"\n✅ 收到分享设备：{dev_id}（需手动注册，权限：{permission}）")
    # 处理设备状态
    else:
        print(f"\n📊 设备状态：{msg.payload.decode()}")


def register_device(dev_id):
    """注册设备"""
    client.publish(f"device/{dev_id}/register", "register")
    print(f"正在注册 {dev_id}...")


def bind_device(dev_id):
    """绑定设备"""
    if dev_id not in REGISTERED_DEVICES:
        print("设备未注册，无法绑定")
        return
    key = DEVICES[dev_id]
    client.publish(f"device/{dev_id}/bind", key.decode())
    print(f"正在绑定 {dev_id}...")


def send_cmd(dev_id, cmd):
    """发送控制指令（权限检查）"""
    if DEVICE_PERMISSIONS.get(dev_id) == "view":
        print(f"❌ 无控制权限，仅能查看 {dev_id} 状态")
        return
    if dev_id not in DEVICES:
        print("设备信息不存在")
        return
    key = DEVICES[dev_id]
    timestamp = str(int(time.time() * 1000))
    nonce = str(uuid.uuid4())[:8]
    content = f"{cmd}|{timestamp}|{nonce}".encode()
    signature = hmac.new(key, content, hashlib.sha256).hexdigest()
    msg = f"{cmd}|{timestamp}|{nonce}|{signature}"
    client.publish(f"device/{dev_id}/control", msg)
    print(f"已发送指令到 {dev_id}: {cmd}")


def share_device(dev_id, target_user, permission="view"):
    """分享设备（携带注册状态，支持自动注册+绑定）"""
    if dev_id not in BOUND_DEVICES:
        print("设备未绑定，无法分享")
        return
    key = DEVICES[dev_id]
    # 携带设备是否已注册的状态
    is_registered = dev_id in REGISTERED_DEVICES
    share_msg = f"share|{dev_id}|{key.decode()}|{permission}|{is_registered}"
    client.publish(f"user/{target_user}/share", share_msg)
    print(f"已将 {dev_id} 以「{permission}」权限分享给 {target_user}")


# 启动用户端
client = mqtt.Client()
client.on_message = on_message
client.connect(MQTT_BROKER, 1883, 60)
client.subscribe("user/register_result")
client.subscribe("user/bind_result")
client.subscribe(f"user/{USER_NAME}/share")
client.subscribe("device/#")
client.loop_start()


# 交互界面
print(f"=== {USER_NAME} 控制中心 ===")
while True:
    print("\n操作：1-注册设备  2-绑定设备  3-控制设备  4-查看设备  5-分享设备  6-退出")
    choice = input("选择操作：")
    
    if choice == "1":
        dev_id = input("输入要注册的设备（aircon/bulb/socket）：")
        if dev_id in DEVICES:
            register_device(dev_id)
        else:
            print("设备不存在")
    
    elif choice == "2":
        dev_id = input("输入要绑定的设备（aircon/bulb/socket）：")
        if dev_id in DEVICES:
            bind_device(dev_id)
        else:
            print("设备不存在")
    
    elif choice == "3":
        if not BOUND_DEVICES:
            print("请先绑定设备")
            continue
        print("已绑定设备：" + "、".join(BOUND_DEVICES))
        dev_id = input("选择设备：")
        if dev_id not in BOUND_DEVICES:
            print("设备未绑定")
            continue
        cmd = input("输入指令（on/off）：")
        if cmd in ["on", "off"]:
            send_cmd(dev_id, cmd)
        else:
            print("无效指令")
    
    elif choice == "4":
        print(f"已注册设备：{REGISTERED_DEVICES if REGISTERED_DEVICES else '暂无'}")
        print(f"已绑定设备：{BOUND_DEVICES if BOUND_DEVICES else '暂无'}")
        print(f"设备权限：{DEVICE_PERMISSIONS if DEVICE_PERMISSIONS else '暂无'}")
    
    elif choice == "5":
        if not BOUND_DEVICES:
            print("请先绑定设备")
            continue
        print("已绑定设备：" + "、".join(BOUND_DEVICES))
        dev_id = input("选择要分享的设备：")
        target_user = input("输入目标用户名（如user2）：")
        permission = input("选择分享权限（view-仅看/control-可控制）：")
        if permission not in ["view", "control"]:
            print("权限无效，默认选择view")
            permission = "view"
        share_device(dev_id, target_user, permission)
    
    elif choice == "6":
        break
    
    else:
        print("输入错误，请选择1-6")