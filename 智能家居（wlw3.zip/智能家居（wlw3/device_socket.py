import paho.mqtt.client as mqtt
import time
import hmac
import hashlib

# 配置（仅修改设备ID和密钥，其余逻辑与空调一致）
MQTT_BROKER = "localhost"
DEVICE_ID = "socket"
CONTROL_TOPIC = f"device/{DEVICE_ID}/control"
STATUS_TOPIC = f"device/{DEVICE_ID}/status"
BIND_TOPIC = f"device/{DEVICE_ID}/bind"
REGISTER_TOPIC = f"device/{DEVICE_ID}/register"  # 注册主题
SECRET_KEY = b"socket_key"
REGISTERED = False  # 是否已注册
BOUND = False       # 是否已绑定


def on_connect(client, userdata, flags, rc):
    print(f"[{DEVICE_ID}] 已连接服务器")
    client.subscribe(CONTROL_TOPIC)
    client.subscribe(BIND_TOPIC)
    client.subscribe(REGISTER_TOPIC)  # 订阅注册请求


def on_message(client, userdata, msg):
    global REGISTERED, BOUND
    try:
        # 1. 处理设备注册
        if msg.topic == REGISTER_TOPIC:
            if not REGISTERED:
                REGISTERED = True
                print(f"[{DEVICE_ID}] 注册成功")
                client.publish(f"user/register_result", f"{DEVICE_ID} 注册成功")
            else:
                print(f"[{DEVICE_ID}] 已完成注册")
            return

        # 2. 处理设备绑定（需先注册）
        if msg.topic == BIND_TOPIC:
            if not REGISTERED:
                print(f"[{DEVICE_ID}] 未注册，无法绑定")
                return
            input_key = msg.payload.decode().encode()
            if input_key == SECRET_KEY:
                BOUND = True
                print(f"[{DEVICE_ID}] 绑定成功")
                client.publish(f"user/bind_result", f"{DEVICE_ID} 绑定成功")
            else:
                print(f"[{DEVICE_ID}] 绑定密钥错误")
            return

        # 3. 处理控制指令（需先注册+绑定）
        if not REGISTERED:
            print(f"[{DEVICE_ID}] 未注册，拒绝指令")
            return
        if not BOUND:
            print(f"[{DEVICE_ID}] 未绑定，拒绝指令")
            return

        # 解析指令（防重放）
        cmd, timestamp, nonce, signature = msg.payload.decode().split("|")
        # 验证时间戳（10秒内有效）
        current_ts = int(time.time() * 1000)
        if abs(current_ts - int(timestamp)) > 10000:
            print(f"[{DEVICE_ID}] 指令过期")
            return
        # 验证签名
        content = f"{cmd}|{timestamp}|{nonce}".encode()
        expected_sign = hmac.new(SECRET_KEY, content, hashlib.sha256).hexdigest()
        if signature != expected_sign:
            print(f"[{DEVICE_ID}] 签名无效")
            return

        # 执行指令+回传状态
        print(f"[{DEVICE_ID}] 执行指令：{cmd}")
        client.publish(STATUS_TOPIC, f"{DEVICE_ID} 状态：{cmd}")

    except Exception as e:
        print(f"[{DEVICE_ID}] 指令错误：{e}")


client = mqtt.Client()
client.on_connect = on_connect
client.on_message = on_message
client.connect(MQTT_BROKER, 1883, 60)
client.loop_forever()