import random
from ss_function import *

# 全局设置：大素数、门限、参与者数量
p = 1000000007
t = 2  # 门限
n = 3  # 3个学生

# 学生1投票
v1 = int(input("学生1输入投票值(0/1)："))
f1 = get_polynomial(v1, t-1, p, '1')
student1 = []
for i in range(1, n+1):
    student1.append(count_polynomial(f1, i, p))
print("学生1的份额：", student1)

# 学生2投票
v2 = int(input("学生2输入投票值(0/1)："))
f2 = get_polynomial(v2, t-1, p, '2')
student2 = []
for i in range(1, n+1):
    student2.append(count_polynomial(f2, i, p))
print("学生2的份额：", student2)

# 学生3投票
v3 = int(input("学生3输入投票值(0/1)："))
f3 = get_polynomial(v3, t-1, p, '3')
student3 = []
for i in range(1, n+1):
    student3.append(count_polynomial(f3, i, p))
print("学生3的份额：", student3)

# 把每个学生持有的所有份额写入文件
f = open('share.txt', 'w')
for i in range(0, n):
    f.write(str(student1[i]) + ' ' + str(student2[i]) + ' ' + str(student3[i]) + '\n')
f.close()
print("份额已保存到 share.txt")