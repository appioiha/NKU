from ss_function import *

# 读取求和份额
f = open('d.txt', 'r')
lines = f.readlines()
f.close()

p = 1000000007
t = 2  # 门限
n = 3

d = []
for line in lines:
    d.append(int(line.strip()))

print("读取到的求和份额：", d)

# 选取任意 2 个份额进行重构（满足 (2,3) 门限）
x = [1, 2]      # 参与者编号
fx = [d[0], d[1]]  # 对应的求和份额

print("正在使用份额重构总票数...")
total_vote = restructure_polynomial(x, fx, t, p)
print("========================================")
print("        投票总票数：", total_vote)
print("      参与投票人数：", n)
print("      投票平均值：", total_vote / n)
print("========================================")