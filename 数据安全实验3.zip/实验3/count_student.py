from ss_function import *

# 读取份额文件
f = open('share.txt', 'r')
lines = f.readlines()
f.close()

p = 1000000007
d = []

# 每个学生本地计算份额和
print("开始本地安全求和（加法同态计算）...")
for line in lines:
    s = line.strip().split()
    v1 = int(s[0])
    v2 = int(s[1])
    v3 = int(s[2])
    # 本地相加，不泄露原始数据
    total = (v1 + v2 + v3) % p
    d.append(total)

print("每个学生的求和份额：", d)

# 保存求和结果
f = open('d.txt', 'w')
for num in d:
    f.write(str(num) + '\n')
f.close()
print("求和份额已保存到 d.txt")