﻿using BookMS;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace bookbook
{
    public partial class gly_xiugai : Form
    {
        string ID = "";

        public gly_xiugai()
        {
            InitializeComponent();
        }

        public gly_xiugai(string id, string name, string author, string press, string number)
        {
            InitializeComponent();
            ID = id; // 关键：保存原始ID
            textBox1.Text = id;
            textBox2.Text = name;
            textBox3.Text = author;
            textBox4.Text = press;
            textBox5.Text = number;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox1.Text))
            {
                MessageBox.Show("书号不能为空，请输入有效的书号");
                return; // 直接返回，不执行后续数据库操作
            }
            try
            {
                // 使用参数化查询防止SQL注入
                string sql = @"update Table_book 
                             set id=@newId, 
                                 [name]=@name, 
                                 author=@author, 
                                 press=@press, 
                                 number=@number 
                             where id=@oldId";

                using (Dao dao = new Dao())
                {
                    SqlCommand cmd = new SqlCommand(sql, dao.connect());
                    cmd.Parameters.AddWithValue("@newId", textBox1.Text);
                    cmd.Parameters.AddWithValue("@name", textBox2.Text);
                    cmd.Parameters.AddWithValue("@author", textBox3.Text);
                    cmd.Parameters.AddWithValue("@press", textBox4.Text);
                    cmd.Parameters.AddWithValue("@number", textBox5.Text);
                    cmd.Parameters.AddWithValue("@oldId", ID); // 使用保存的原始ID

                    int result = cmd.ExecuteNonQuery();
                    if (result > 0)
                    {
                        MessageBox.Show("修改成功");
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("修改失败，可能是ID不存在");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"修改时出错: {ex.Message}");
            }
        }
    }
}
