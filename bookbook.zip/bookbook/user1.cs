﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bookbook
{
    public partial class user1 : Form
    {
        public user1()
        {
            InitializeComponent();
        }

        private void 图书查看和借阅ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            user_check u = new user_check();
            u.ShowDialog();
        }

        private void 我的图书ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            user_my myBooksForm = new user_my();

            // 显示窗体（可根据需要选择ShowDialog或Show）
            myBooksForm.ShowDialog();
        }
    }
}
