﻿using System.Data;
using System;
using System.Data.SqlClient;

namespace BookMS
{
    // 数据库访问对象类，负责与SQL Server数据库交互
    class Dao : IDisposable
    {
        // 数据库连接对象，用于建立与数据库的连接
        private SqlConnection _connection;

        // 获取数据库连接，如果连接不存在或已关闭，则创建并打开新连接
        public SqlConnection connect()
        {
            if (_connection == null || _connection.State == ConnectionState.Closed)
            {
                // 数据库连接字符串，包含服务器地址、数据库名、用户名和密码
                string str = @"Data Source=LAPTOP-CCQV56U1; 
                   Initial Catalog=booksys; 
                   User ID=sa; 
                   Password=123456;";
                _connection = new SqlConnection(str);
                _connection.Open(); // 打开数据库连接
            }
            return _connection;
        }

        // 创建SQL命令对象，用于执行SQL语句
        public SqlCommand command(string sql)
        {
            return new SqlCommand(sql, connect()); // 使用当前连接创建命令
        }

        // 执行非查询SQL语句（如INSERT、UPDATE、DELETE）
        // 返回受影响的行数
        public int Execute(string sql)
        {
            using (var cmd = command(sql))
            {
                return cmd.ExecuteNonQuery(); // 执行命令并返回结果
            }
        }

        // 执行查询SQL语句，返回数据读取器
        // 用于逐行读取查询结果
        public SqlDataReader read(string sql)
        {
            return command(sql).ExecuteReader(); // 执行查询并返回数据读取器
        }

        // 关闭数据库连接
        public void DaoClose()
        {
            if (_connection != null && _connection.State != ConnectionState.Closed)
            {
                _connection.Close(); // 关闭连接
            }
        }

        // 实现IDisposable接口，用于释放资源
        // 使用using语句时会自动调用此方法
        public void Dispose()
        {
            DaoClose(); // 关闭数据库连接
        }
    }
}