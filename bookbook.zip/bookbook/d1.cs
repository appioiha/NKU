﻿using System;
using System.Data;

namespace bookbook
{
    internal class d
    {
        public d()
        {
        }

        internal static void DaoClose()
        {
            throw new NotImplementedException();
        }

        internal static IDataReader read(string sql)
        {
            throw new NotImplementedException();
        }
    }
}