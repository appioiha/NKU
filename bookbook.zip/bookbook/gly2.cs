﻿using BookMS;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bookbook
{
    public partial class gly2 : Form
    {
        public gly2()
        {
            InitializeComponent();
            Table();
        }
        public void TableID()///根据编号查
        {
            dataGridView1.Rows.Clear();///清空旧数据
            Dao dao = new Dao();
            string sql = $"select * from Table_book where id='{textBox1.Text}'"; ;///sql语句，查询
            IDataReader dc = dao.read(sql);
            while (dc.Read())
            {
                dataGridView1.Rows.Add(dc[0].ToString(), dc[1].ToString(), dc[2].ToString(), dc[3].ToString(), dc[4].ToString());
            }
            dc.Close();
            dao.DaoClose();
        }

        public void TableName()////根据书名查
        {
            dataGridView1.Rows.Clear();///清空旧数据
            Dao dao = new Dao();
            string sql = $"select * from Table_book where [name] like '%{textBox2.Text}%'"; ///修正SQL语句;///sql语句，模糊查询
            IDataReader dc = dao.read(sql);
            while (dc.Read())
            {
                dataGridView1.Rows.Add(dc[0].ToString(), dc[1].ToString(), dc[2].ToString(), dc[3].ToString(), dc[4].ToString());
            }
            dc.Close();
            dao.DaoClose();
        }
        private void gly2_Load(object sender, EventArgs e)
        {
            label2.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString()+ dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            gly3 a = new gly3();
            a.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            TableID();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            label2.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString() + dataGridView1.SelectedRows[0].Cells[1].Value.ToString();

        }


        
        ////从数据库读取数据并显示
        public void Table() {
            dataGridView1.Rows.Clear();///清空旧数据
            Dao dao = new Dao();
            string sql = "select* from Table_book";///sql语句，读取所有的信息
            IDataReader dc = dao.read(sql);
            while (dc.Read())
            {
                dataGridView1.Rows.Add(dc[0].ToString(), dc[1].ToString(), dc[2].ToString(), dc[3].ToString(), dc[4].ToString());
            }
            dc.Close();
            dao.DaoClose();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridView1.SelectedRows.Count == 0)
                {
                    MessageBox.Show("请先选中要删除的图书记录");
                    return;
                }

                string id = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                label2.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString() + dataGridView1.SelectedRows[0].Cells[1].Value.ToString();

                string bookName = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();

                DialogResult dr = MessageBox.Show($"确认删除{bookName}吗？",
                    "确认删除",
                    MessageBoxButtons.OKCancel,
                    MessageBoxIcon.Warning);

                if (dr == DialogResult.OK)
                {
                    // 使用参数化查询
                    string sql = "delete from Table_book where id=@id";

                    using (Dao dao = new Dao())
                    {
                        SqlCommand cmd = new SqlCommand(sql, dao.connect());
                        cmd.Parameters.AddWithValue("@id", id);

                        int affectedRows = cmd.ExecuteNonQuery();
                        if (affectedRows > 0)
                        {
                            MessageBox.Show("删除成功");
                            Table(); // 刷新表格
                        }
                        else
                        {
                            MessageBox.Show("删除失败，可能是记录不存在");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"删除时出错：{ex.Message}");
            }
        }

        private void dataGridView1_Click(object sender, EventArgs e)
        {

        }
        private void label2_Click_1(object sender, EventArgs e)
        {
            label2.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString() + dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try {

                string id = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                string name = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
                string author = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
                string press = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
                string number = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();
                gly_xiugai xg = new gly_xiugai(id,name,author,press,number);
                xg.ShowDialog();
                Table();///刷新数据

            }
            catch {
                MessageBox.Show("error");
            }
            
        }

        private void button6_Click(object sender, EventArgs e)
        {
            TableName();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Table();
            textBox1.Text = "";
            textBox2.Text = "";
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
