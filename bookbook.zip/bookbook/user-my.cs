﻿using BookMS;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Reflection.Emit;
using System.Windows.Forms;

namespace bookbook
{
    public partial class user_my : Form
    {
        public user_my()
        {
            InitializeComponent();
            Table();
        }

        // 根据编号查询（添加用户过滤）
        public void TableID()
        {
            dataGridView1.Rows.Clear();

            if (string.IsNullOrEmpty(textBox1.Text))
            {
                MessageBox.Show("请输入图书编号");
                return;
            }

            using (Dao dao = new Dao())
            {
                string sql = @"
                    SELECT l.[no], l.[bid], b.[name] as bname, l.[datetime] 
                    FROM Table_lend l
                    LEFT JOIN Table_book b ON l.bid = b.id
                    WHERE l.[bid] = @bid
                      AND l.[uid] = @uid";

                try
                {
                    using (SqlCommand cmd = new SqlCommand(sql, dao.connect()))
                    {
                        cmd.Parameters.AddWithValue("@bid", textBox1.Text);
                        cmd.Parameters.AddWithValue("@uid", Data.UID);

                        using (IDataReader dc = cmd.ExecuteReader())
                        {
                            while (dc.Read())
                            {
                                dataGridView1.Rows.Add(
                                    dc[0].ToString(),  // no
                                    dc[1].ToString(),  // bid
                                    dc[2].ToString(),  // bname
                                    dc[3].ToString()); // datetime
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"查询失败: {ex.Message}");
                }
            }
        }

        // 根据书名查询（添加用户过滤）
        public void TableName()
        {
            dataGridView1.Rows.Clear();

            if (string.IsNullOrEmpty(textBox2.Text))
            {
                MessageBox.Show("请输入图书名称");
                return;
            }

            using (Dao dao = new Dao())
            {
                string sql = @"
                    SELECT l.[no], l.[bid], b.[name] as bname, l.[datetime] 
                    FROM Table_lend l
                    LEFT JOIN Table_book b ON l.bid = b.id
                    WHERE b.[name] LIKE @name
                      AND l.[uid] = @uid";

                try
                {
                    using (SqlCommand cmd = new SqlCommand(sql, dao.connect()))
                    {
                        cmd.Parameters.AddWithValue("@name", $"%{textBox2.Text}%");
                        cmd.Parameters.AddWithValue("@uid", Data.UID);

                        using (IDataReader dc = cmd.ExecuteReader())
                        {
                            while (dc.Read())
                            {
                                dataGridView1.Rows.Add(
                                    dc[0].ToString(),  // no
                                    dc[1].ToString(),  // bid
                                    dc[2].ToString(),  // bname
                                    dc[3].ToString()); // datetime
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"查询失败: {ex.Message}");
                }
            }
        }

        // 显示所有借阅记录（已存在，无需修改）
        public void Table()
        {
            dataGridView1.Rows.Clear();

            using (Dao dao = new Dao())
            {
                string sql = @"
                    SELECT l.[no], l.[bid], b.[name] as bname, l.[datetime] 
                    FROM Table_lend l
                    LEFT JOIN Table_book b ON l.bid = b.id
                    WHERE l.[uid] = @uid";

                try
                {
                    using (SqlCommand cmd = new SqlCommand(sql, dao.connect()))
                    {
                        cmd.Parameters.AddWithValue("@uid", Data.UID);

                        using (IDataReader dc = cmd.ExecuteReader())
                        {
                            while (dc.Read())
                            {
                                dataGridView1.Rows.Add(
                                    dc[0].ToString(),  // no
                                    dc[1].ToString(),  // bid
                                    dc[2].ToString(),  // bname
                                    dc[3].ToString()); // datetime
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"查询失败: {ex.Message}");
                }
            }
        }

        // 还书功能（已存在，无需修改）
        private void button1_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("请先选择要归还的图书");
                return;
            }

            string no = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            string id = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();

            using (Dao dao = new Dao())
            {
                string sql = $@"
                    BEGIN TRANSACTION;
                    DELETE FROM Table_lend WHERE [no] = @no;
                    UPDATE Table_book SET number = number + 1 WHERE id = @id;
                    COMMIT TRANSACTION;";

                try
                {
                    using (SqlCommand cmd = new SqlCommand(sql, dao.connect()))
                    {
                        cmd.Parameters.AddWithValue("@no", no);
                        cmd.Parameters.AddWithValue("@id", id);

                        int rowsAffected = cmd.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("归还成功");
                            Table(); // 刷新表格
                        }
                        else
                        {
                            MessageBox.Show("归还失败");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"归还出错: {ex.Message}");
                }
            }
        }

        private void user_my_Load(object sender, EventArgs e) { }

        private void button5_Click(object sender, EventArgs e)
        {
            TableID();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            TableName();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // 保留空实现
        }
    }
}