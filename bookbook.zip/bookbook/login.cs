﻿using BookMS;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bookbook
{
    public partial class login : Form
    {
        public login()
        {
            InitializeComponent();
        }

        private void 欢迎登录图书管理系统_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "")
            {
                Login();
            }
            else
            {
                MessageBox.Show("输入有空项，请重新输入");
            }
        }

        // 登陆方法，验证是否允许登陆，允许返回真
        public Boolean Login()
        {
            // 用户登陆
            if (radioButtonuser.Checked == true)
            {
                Dao dao = new Dao();
                string sql = "select * from Table_user where id='" + textBox1.Text + "' and password='" + textBox2.Text + "'";
                IDataReader dc = dao.read(sql);
                if (dc.Read())
                {

                    Data.UID = dc["id"].ToString();
                    Data.UName= dc["name"].ToString();///方便后续借书还书

                    MessageBox.Show("登陆成功");
                    user1 user = new user1();
                    this.Hide();
                    user.ShowDialog();
                    this.Show();////弹窗设置

                    return true;

                }
                else {
                    MessageBox.Show("登录失败");
                    return false;
                
                }

                dao.DaoClose();
            }

            // 管理员登陆
            if (radioButtonadm.Checked == true)
            {
                Dao dao = new Dao();
                string sql = "select * from Table_gly where id='" + textBox1.Text + "' and password='" + textBox2.Text + "'";
                IDataReader dc = dao.read(sql);
                if (dc.Read())
                {
                    MessageBox.Show("登陆成功");

                    gly1 a = new gly1();
                    this.Hide();
                    a.ShowDialog();
                    this.Show();
                    return true;

                }
                else
                {
                    MessageBox.Show("登陆失败");
                    return false;
                }
                dao.DaoClose();

            }
            return false;
        }



        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
