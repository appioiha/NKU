package com.example.myapplication2;

import android.app.Activity;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.RotateAnimation;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.Locale;

public class MainActivity extends Activity implements SensorEventListener {

    // 视图组件
    private ImageView compassImage;
    private TextView tvOrientationX, tvOrientationY, tvOrientationZ;
    private TextView tvMotionState;
    private TextView tvDirectionX, tvDirectionY, tvDirectionZ;

    // 传感器相关
    private SensorManager sensorManager;
    private Sensor accelerometer;
    private Sensor magnetometer;
    private Sensor rotationSensor;

    // 方向计算变量
    private float currentDegree = 0f;
    private float[] rotationMatrix = new float[9];
    private float[] orientationAngles = new float[3];
    private float[] accelerometerData = new float[3];
    private float[] magnetometerData = new float[3];

    // 运动检测变量
    private static final float ALPHA = 0.1f;
    private float[] gravity = new float[3];
    private float[] linearAcceleration = new float[3];
    private float[] currentVelocity = new float[3];
    private float[] lastVelocity = new float[3];
    private long lastIntegrationTime = 0;
    private float totalSpeed = 0.0f;
    private boolean isFirstAccelSample = true;

    // 方向状态变量
    private float[] directionAngles = new float[3]; // 手机方向角度(X/Y/Z)
    private float[] directionStdDev = new float[3]; // 方向标准差(用于判断稳定性)
    private float[] lastDirection = new float[3];
    private static final float STRAIGHT_THRESHOLD = 15.0f; // 直线运动角度阈值(度)
    private static final float STABILITY_THRESHOLD = 5.0f; // 方向稳定性阈值(度)

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 初始化视图
        initViews();

        // 获取传感器服务
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        magnetometer = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
        rotationSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
    }

    private void initViews() {
        compassImage = findViewById(R.id.compassImage);
        tvOrientationX = findViewById(R.id.tvOrientationX);
        tvOrientationY = findViewById(R.id.tvOrientationY);
        tvOrientationZ = findViewById(R.id.tvOrientationZ);
        tvMotionState = findViewById(R.id.tvMotionState);
        tvDirectionX = findViewById(R.id.tvDirectionX);
        tvDirectionY = findViewById(R.id.tvDirectionY);
        tvDirectionZ = findViewById(R.id.tvDirectionZ);
    }

    @Override
    protected void onResume() {
        super.onResume();
        // 注册传感器监听
        if (accelerometer != null) {
            sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_GAME);
        }
        if (magnetometer != null) {
            sensorManager.registerListener(this, magnetometer, SensorManager.SENSOR_DELAY_GAME);
        }
        if (rotationSensor != null) {
            sensorManager.registerListener(this, rotationSensor, SensorManager.SENSOR_DELAY_GAME);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this);
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // 可以留空
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        switch (event.sensor.getType()) {
            case Sensor.TYPE_ACCELEROMETER:
                System.arraycopy(event.values, 0, accelerometerData, 0, event.values.length);
                updateVelocity(event);
                break;
            case Sensor.TYPE_MAGNETIC_FIELD:
                System.arraycopy(event.values, 0, magnetometerData, 0, event.values.length);
                break;
            case Sensor.TYPE_ROTATION_VECTOR:
                updateOrientation(event);
                break;
        }
    }

    private void updateOrientation(SensorEvent event) {
        // 获取旋转矩阵和方向角度
        SensorManager.getRotationMatrixFromVector(rotationMatrix, event.values);
        SensorManager.getOrientation(rotationMatrix, orientationAngles);

        // 转换为角度并更新UI
        updateOrientationUI();

        // 计算手机方向角度(X/Y/Z轴)
        calculateDeviceDirection();

        // 更新运动状态判断
        updateMotionStatus();
    }

    private void updateOrientationUI() {
        float azimuth = (float) Math.toDegrees(orientationAngles[0]);
        float pitch = (float) Math.toDegrees(orientationAngles[1]);
        float roll = (float) Math.toDegrees(orientationAngles[2]);

        // 更新方向显示
        tvOrientationX.setText(String.format(Locale.getDefault(), "方位角: %.1f°", azimuth));
        tvOrientationY.setText(String.format(Locale.getDefault(), "俯仰角: %.1f°", pitch));
        tvOrientationZ.setText(String.format(Locale.getDefault(), "横滚角: %.1f°", roll));

        // 更新指南针动画
        RotateAnimation ra = new RotateAnimation(
                currentDegree, -azimuth,
                Animation.RELATIVE_TO_SELF, 0.5f,
                Animation.RELATIVE_TO_SELF, 0.5f
        );
        ra.setDuration(200);
        ra.setFillAfter(true);
        compassImage.startAnimation(ra);
        currentDegree = -azimuth;
    }

    private void calculateDeviceDirection() {
        // 计算手机在各轴的方向角度
        directionAngles[0] = (float) Math.toDegrees(Math.atan2(
                rotationMatrix[5], rotationMatrix[8])); // X轴方向
        directionAngles[1] = (float) Math.toDegrees(Math.atan2(
                -rotationMatrix[2], Math.sqrt(rotationMatrix[5]*rotationMatrix[5] + rotationMatrix[8]*rotationMatrix[8]))); // Y轴方向
        directionAngles[2] = (float) Math.toDegrees(Math.atan2(
                rotationMatrix[1], rotationMatrix[4])); // Z轴方向

        // 更新方向显示
        tvDirectionX.setText(String.format(Locale.getDefault(), "X轴方向: %.1f°", directionAngles[0]));
        tvDirectionY.setText(String.format(Locale.getDefault(), "Y轴方向: %.1f°", directionAngles[1]));
        tvDirectionZ.setText(String.format(Locale.getDefault(), "Z轴方向: %.1f°", directionAngles[2]));

        // 计算方向变化标准差(用于判断稳定性)
        for (int i = 0; i < 3; i++) {
            directionStdDev[i] = 0.9f * directionStdDev[i] + 0.1f * Math.abs(directionAngles[i] - lastDirection[i]);
            lastDirection[i] = directionAngles[i];
        }
    }

    private void updateVelocity(SensorEvent event) {
        long currentTime = System.currentTimeMillis();

        if (isFirstAccelSample) {
            lastIntegrationTime = currentTime;
            isFirstAccelSample = false;
            return;
        }

        float deltaTime = (currentTime - lastIntegrationTime) / 1000.0f;
        if (deltaTime <= 0) return;

        // 分离重力分量
        gravity[0] = ALPHA * gravity[0] + (1 - ALPHA) * event.values[0];
        gravity[1] = ALPHA * gravity[1] + (1 - ALPHA) * event.values[1];
        gravity[2] = ALPHA * gravity[2] + (1 - ALPHA) * event.values[2];

        // 计算线性加速度
        linearAcceleration[0] = event.values[0] - gravity[0];
        linearAcceleration[1] = event.values[1] - gravity[1];
        linearAcceleration[2] = event.values[2] - gravity[2];

        // 积分得到速度(梯形法则)
        currentVelocity[0] += (lastVelocity[0] + linearAcceleration[0]) * 0.5f * deltaTime;
        currentVelocity[1] += (lastVelocity[1] + linearAcceleration[1]) * 0.5f * deltaTime;
        currentVelocity[2] += (lastVelocity[2] + linearAcceleration[2]) * 0.5f * deltaTime;

        lastVelocity[0] = linearAcceleration[0];
        lastVelocity[1] = linearAcceleration[1];
        lastVelocity[2] = linearAcceleration[2];

        // 计算总速度(忽略Z轴)
        totalSpeed = (float) Math.sqrt(currentVelocity[0]*currentVelocity[0] + currentVelocity[1]*currentVelocity[1]);

        // 速度衰减
        float decayFactor = (float) Math.exp(-deltaTime * 2.0f);
        currentVelocity[0] *= decayFactor;
        currentVelocity[1] *= decayFactor;
        currentVelocity[2] *= decayFactor;

        // 静止判断
        if (totalSpeed < 0.1f) {
            totalSpeed = 0;
            currentVelocity[0] = currentVelocity[1] = currentVelocity[2] = 0;
        }

        lastIntegrationTime = currentTime;
    }

    private void updateMotionStatus() {
        // 判断是否静止
        if (totalSpeed < 0.1f) {
            tvMotionState.setText("状态: 静止");
            return;
        }

        // 判断方向稳定性
        boolean isDirectionStable = directionStdDev[0] < STABILITY_THRESHOLD &&
                directionStdDev[1] < STABILITY_THRESHOLD &&
                directionStdDev[2] < STABILITY_THRESHOLD;

        // 判断是否直线运动
        boolean isStraight = Math.abs(directionAngles[1]) < STRAIGHT_THRESHOLD &&
                Math.abs(directionAngles[2]) < STRAIGHT_THRESHOLD &&
                isDirectionStable;

        if (isStraight) {
            tvMotionState.setText("状态: 直线行走");
        } else {
            tvMotionState.setText("状态: 非直线行走");
        }
    }
}