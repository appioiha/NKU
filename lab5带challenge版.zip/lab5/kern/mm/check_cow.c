#include <proc.h>
#include <vmm.h>
#include <pmm.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
#include <unistd.h>

static void
cow_test(void) {
    cprintf("=== COW Test Start ===\n");
    
    // 分配测试页面
    char *addr = (char *)0x1000;
    struct mm_struct *mm = current->mm;
    
    // 创建内存映射
    struct vma_struct *vma = find_vma(mm, (uintptr_t)addr);
    if (vma == NULL) {
        vma = vma_create((uintptr_t)addr, (uintptr_t)addr + PGSIZE, VM_READ | VM_WRITE);
        insert_vma_struct(mm, vma);
    }
    
    // 分配物理页面
    struct Page *page = alloc_pages(1);  // 使用 alloc_pages
    page_insert(mm->pgdir, page, (uintptr_t)addr, PTE_W | PTE_U);
    
    // 写入初始数据
    char *kvaddr = page2kva(page);
    strcpy(kvaddr, "Hello COW");
    cprintf("Original data: %s\n", kvaddr);
    
    // 创建子进程 - 使用 do_fork 而不是 fork
    int pid = do_fork(0, 0, NULL);  // 使用内核的 do_fork
    
    if (pid == 0) {
        // 子进程
        cprintf("Child process reading: %s\n", kvaddr);
        
        // 子进程写入 - 应该触发COW
        strcpy(kvaddr, "Child modified");
        cprintf("Child process after write: %s\n", kvaddr);
        
        do_exit(0);  // 使用 do_exit
    } else {
        // 父进程等待
        do_wait(pid, NULL);  // 使用 do_wait
        
        // 检查父进程数据是否保持不变
        cprintf("Parent process data after child write: %s\n", kvaddr);
        if (strcmp(kvaddr, "Hello COW") == 0) {
            cprintf("COW test passed: parent data unchanged\n");
        } else {
            cprintf("COW test failed: parent data changed\n");
        }
    }
    
    cprintf("=== COW Test Finished ===\n");
}

void check_cow(void) {
    cow_test();
}