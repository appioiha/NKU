package com.example.accelerometer;

import androidx.appcompat.app.AppCompatActivity;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView acceleration_x;//x方向的加速度
    TextView acceleration_y;//y方向的加速度
    TextView acceleration_z;//z方向的加速度
    TextView acceleration_total;//显示总加速度
    //显示运动情况
    TextView ifmove;
    // 显示步数
    TextView stepCountText;
    SensorManager mySensorManager;//SensorManager对象引用
    private int stepCount = 0;
    private boolean isAboveUpperThreshold = false;
    private static final float STEP_UPPER_THRESHOLD = 2.0f; // 上限阈值
    private static final float STEP_LOWER_THRESHOLD = 1.0f; // 下限阈值
    private static final int FILTER_SIZE = 5;
    private float[] filterBuffer = new float[FILTER_SIZE];
    private int filterIndex = 0;
    private float filteredAcceleration = 0;

    @Override
    public void onCreate(Bundle savedInstanceState) {//重写onCreate方法
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);//设置当前的用户界面
        acceleration_x = (TextView) findViewById(R.id.acceleration_x);//得到acceleration_x的引用
        acceleration_y = (TextView) findViewById(R.id.acceleration_y);//得到acceleration_y的引用
        acceleration_z = (TextView) findViewById(R.id.acceleration_z);//得到acceleration_z的引用
        acceleration_total = (TextView) findViewById(R.id.acceleration_total);//得到acceleration_total的引用

        //设置一个用于判断是否运动的控件
        ifmove = (TextView) findViewById(R.id.ifmove);//得到ifmove的引用
        stepCountText = (TextView) findViewById(R.id.step_count); // 得到步数显示控件的引用
        mySensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);//获得SensorManager
    }

    private SensorEventListener mySensorListener = new SensorEventListener() {
        @Override
        public void onSensorChanged(SensorEvent sensorEvent) {
            if (sensorEvent.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
                float[] values = sensorEvent.values;
                //通过开平方和得到总加速度
                float total_acceleration = (float) Math.sqrt(sensorEvent.values[0] * sensorEvent.values[0]
                        + sensorEvent.values[1] * sensorEvent.values[1]
                        + sensorEvent.values[2] * sensorEvent.values[2]);

                // 滑动平均滤波
                filterBuffer[filterIndex] = total_acceleration;
                filterIndex = (filterIndex + 1) % FILTER_SIZE;
                float sum = 0;
                for (float value : filterBuffer) {
                    sum += value;
                }
                filteredAcceleration = sum / FILTER_SIZE;

                //设置加速度的显示情况
                acceleration_x.setText("acceleration_x：" + sensorEvent.values[0]);
                acceleration_y.setText("acceleration_y：" + sensorEvent.values[1]);
                acceleration_z.setText("acceleration_z：" + sensorEvent.values[2]);
                acceleration_total.setText("acceleration_total：" + total_acceleration);

                //通过与本地9.8左右的加速度进行比较从而判断手机是否运动
                //因为实际本地加速度会在9.8-9.9之间浮动，通过物理知识可知小于9.8是在上升，大于9.9是在下降
                if (filteredAcceleration < 9.9 && filteredAcceleration > 9.8) {
                    ifmove.setText("At rest");
                } else if (filteredAcceleration >= 9.9) {
                    ifmove.setText("In motion,downing");
                } else if (filteredAcceleration <= 9.8) {
                    ifmove.setText("In motion,uping");
                }

                // 改进后的步数检测逻辑
                if (filteredAcceleration > STEP_UPPER_THRESHOLD) {
                    isAboveUpperThreshold = true;
                } else if (isAboveUpperThreshold && filteredAcceleration < STEP_LOWER_THRESHOLD) {
                    stepCount++;
                    stepCountText.setText("Step Count: " + stepCount);
                    isAboveUpperThreshold = false;
                }
            }
        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int i) {
        }
    };

    @Override
    protected void onResume() {//重写的onResume方法
        mySensorManager.registerListener(//注册监听
                mySensorListener, //监听器SensorListener对象
                mySensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER),//传感器的类型为加速度
                SensorManager.SENSOR_DELAY_UI//传感器事件传递的频度
        );
        super.onResume();
    }

    @Override
    protected void onPause() {//重写onPause方法
        mySensorManager.unregisterListener(mySensorListener);//取消注册监听器
        super.onPause();
    }
}