#pragma once
#include <winsock2.h>
#include <ws2tcpip.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#pragma comment(lib, "ws2_32.lib")

// ��������
#define MAX_DATA_SIZE 1024    
#define WINDOW_SIZE 8         
#define MAX_RETRY 5           
#define TIMEOUT_MS 500        
#define CRC16_POLY 0x8005     

#ifndef min
#define min(a,b) ((a) < (b) ? (a) : (b))
#endif

// ��������
typedef enum {
    SYN = 0,
    DATA,
    ACK,
    FIN,
    FIN_ACK
} PacketType;

// ���Ľṹ
typedef struct {
    unsigned char type;
    unsigned int seq;
    unsigned int ack;
    unsigned short win;
    unsigned int sack_bitmap;
    unsigned short checksum;
    unsigned short data_len;
    char data[MAX_DATA_SIZE];
} RUDP_Packet;

// ����CRC16У���
unsigned short crc16(const unsigned char* data, int len) {
    unsigned short crc = 0xFFFF;
    for (int i = 0; i < len; i++) {
        crc ^= (unsigned short)data[i] << 8;
        for (int j = 0; j < 8; j++) {
            if (crc & 0x8000)
                crc = (crc << 1) ^ CRC16_POLY;
            else
                crc <<= 1;
        }
    }
    return crc;
}

// ��֤У���
int verify_checksum(RUDP_Packet* pkt) {
    unsigned short old_checksum = pkt->checksum;
    pkt->checksum = 0;
    unsigned short new_checksum = crc16((unsigned char*)pkt, sizeof(RUDP_Packet));
    pkt->checksum = old_checksum;
    return (old_checksum == new_checksum);
}

// ���У���
void fill_checksum(RUDP_Packet* pkt) {
    pkt->checksum = 0;
    pkt->checksum = crc16((unsigned char*)pkt, sizeof(RUDP_Packet));
}

// ��ʼ��Winsock
int init_winsock() {
    WSADATA wsaData;
    int ret = WSAStartup(MAKEWORD(2, 2), &wsaData);
    if (ret != 0) {
        printf("Winsock��ʼ��ʧ��: %d\n", ret);
        return -1;
    }
    return 0;
}

// �ر�Winsock
void cleanup_winsock() {
    WSACleanup();
    printf("Winsock�ѹر�\n");
}